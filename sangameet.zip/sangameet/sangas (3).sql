-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 03, 2023 at 11:05 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sangas`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE `addresses` (
  `id` int(67) NOT NULL,
  `users_id` int(67) NOT NULL,
  `type` varchar(67) NOT NULL,
  `house` varchar(67) NOT NULL,
  `street` varchar(67) NOT NULL,
  `city` varchar(45) NOT NULL,
  `state` varchar(45) NOT NULL,
  `country` varchar(45) NOT NULL,
  `pincode` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `addresses`
--

INSERT INTO `addresses` (`id`, `users_id`, `type`, `house`, `street`, `city`, `state`, `country`, `pincode`) VALUES
(1, 1, ' p', '1', '2', 'chandigarh', '453', '454', '54'),
(2, 1, 'r', '543', '543', 'chandigarh', '45', '433', '543'),
(3, 2, 'r', '67/c', ' 90', 'chandigarh', ' punjab', ' India', ' 147001'),
(4, 2, ' p', '45/b', ' 90', 'chandigarh', ' punjab', ' India', ' 147001'),
(5, 3, 'r', '67/c', ' sector 34', 'chandigarh', ' punjab', ' India', ' 147001'),
(6, 3, ' p', '45/b', ' sector 90', 'chandigarh', ' punjab', ' India', ' 147001'),
(11, 17, 'r', '67/c', ' sector 556', ' chandigarh', ' punjab', ' India', ' 147001'),
(12, 17, ' p', '45/b', ' sector 45', ' mohali', ' punjab', ' India', ' 147001'),
(13, 18, 'r', '67/c', ' sector 556', ' chandigarh', ' punjab', ' India', ' 147001'),
(14, 18, ' p', '45/b', ' sector 45', ' mohali', ' punjab', ' India', ' 147001'),
(16, 19, 'r', 'ewr', ' erw', ' er', ' er', ' r', ' ere'),
(17, 19, ' p', 'rew', ' ewr', ' er', ' re', ' re', ' er'),
(18, 20, 'r', 'er', ' erw', ' er', ' er', ' er', ' er'),
(19, 20, ' p', 'ewr', ' erer', ' er', ' ewr', ' er', ' er'),
(20, 25, 'r', 'er', ' ewrt', ' ert5yu', ' hgjk', ' hjkl', ' hjk'),
(21, 25, ' p', 'yuio', ' uiop', ' jkljk', ' l', ' jhkl', ' hjkl'),
(32, 29, 'r', '', ' ', ' ', ' ', ' ', ' '),
(33, 29, ' p', '', ' ', ' ', ' ', ' ', ' '),
(35, 30, 'r', '67', 'sector 45', 'chandigarh', 'punjab', 'India', '147001'),
(36, 30, ' p', '7867', 'modal', 'chandigarh', 'punjab', 'India', '147001'),
(37, 31, ' r', '67/c', 'sector 49', 'chandigarh', 'punjab', 'India', '147001'),
(38, 31, ' p', '78/c', 'sector 108', 'chandigarh', 'punjab', 'India', '147001'),
(41, 37, ' r', '67/c', ' sector 34', ' chandigarh', ' punjab', ' India', ' 147001'),
(42, 37, ' p', '45/b', ' sector 45', ' chandigarh', ' punjab', ' India', ' 147001'),
(43, 38, ' r', '67/c', ' sector 34', ' chandigarh', ' punjab', ' India', ' 147001'),
(44, 38, ' p', '45/b', ' sector 45', ' chandigarh', ' punjab', ' India', ' 147001'),
(45, 39, ' r', '67/c', ' sector 34', ' chandigarh', ' punjab', ' India', ' 147001'),
(46, 39, ' p', '45/b', ' sector 45', ' chandigarh', ' punjab', ' India', ' 147001'),
(54, 40, ' r', '67/c', ' 90', ' chandigarh', ' punjab', ' India', ' 147001'),
(55, 40, ' p', '45/b', ' 90', ' chandigarh', ' punjab', ' India', ' 147001'),
(56, 41, ' r', '67/c', ' 90', ' chandigarh', ' punjab', ' India', ' 147001'),
(57, 41, ' p', '45/b', ' 90', ' chandigarh', ' punjab', ' India', ' 147001'),
(63, 44, ' r', '67/c', ' 90', ' chandigarh', ' punjab', ' India', ' 147001'),
(64, 44, ' p', '45/b', ' 90', ' chandigarh', ' punjab', ' India', ' 147001'),
(67, 45, ' r', '67/c', ' 90', ' chandigarh', ' punjab', ' India', ' 147001'),
(68, 45, ' p', '45/b', ' 90', ' mohali', ' punjab', ' India', ' 147001'),
(69, 46, ' r', '67/c', ' 90', ' chandigarh', ' punjab', ' India', ' 147001'),
(70, 46, ' p', '45/b', ' 90', ' mohali', ' punjab', ' India', ' 147001'),
(71, 47, ' r', '', ' ', ' ', ' ', ' ', ' '),
(72, 47, ' p', '', ' ', ' ', ' ', ' ', ' '),
(77, 50, ' r', '', ' ', ' ', ' ', ' ', ' '),
(78, 50, ' p', '', ' ', ' ', ' ', ' ', ' '),
(81, 51, ' r', '', ' ', ' ', ' ', ' ', ' '),
(82, 51, ' p', '', ' ', ' ', ' ', ' ', ' '),
(86, 52, ' r', '', ' ', ' ', ' ', ' ', ' '),
(87, 52, ' p', '', ' ', ' ', ' ', ' ', ' '),
(88, 53, ' r', '', ' ', ' ', ' ', ' ', ' '),
(89, 53, ' p', '', ' ', ' ', ' ', ' ', ' '),
(90, 54, ' r', '', ' ', ' ', ' ', ' ', ' '),
(91, 54, ' p', '', ' ', ' ', ' ', ' ', ' '),
(98, 55, ' r', '', ' ', ' ', ' ', ' ', ' '),
(99, 55, ' p', '', ' ', ' ', ' ', ' ', ' '),
(106, 56, ' r', '', ' ', ' ', ' ', ' ', ' '),
(107, 56, ' p', '', ' ', ' ', ' ', ' ', ' '),
(108, 57, ' r', '67/c', ' 90', ' chandigarh', ' punjab', ' India', ' 147001'),
(109, 57, ' p', '45/b', ' 90', ' chandigarh', ' punjab', ' India', ' 147001'),
(110, 66, ' r', '', ' ', ' ', ' ', ' ', ' '),
(111, 66, ' p', '', ' ', ' ', ' ', ' ', ' '),
(116, 68, ' ', 'er', ' ', ' ', ' ', ' ', ' '),
(117, 68, ' ', 'yuio', ' ', ' ', ' ', ' ', ' '),
(121, 69, ' r', 'Officiis elit quia ', ' Quisquam aliquid sap', ' Dolores nihil laboru', ' Laudantium similiqu', ' Voluptatem soluta od', ' Reprehenderit enim '),
(122, 69, ' p', '924 South Second Boulevard', ' 11 East Rocky Oak Avenue', ' 64 White Nobel Court', ' 63 Oak Court', ' 740 East White Clarendon Avenue', ' 811 South Nobel Lane'),
(123, 70, ' r', 'Sint beatae hic cupi', ' Eiusmod quis incidun', ' Ipsam sit quis sit e', ' Adipisci vel ut null', ' Commodi voluptate vo', ' Blanditiis deserunt '),
(124, 70, ' p', '74 West Old Street', ' 365 West Rocky Oak Road', ' 88 North Second Court', ' 54 North Nobel Extension', ' 41 White Milton Boulevard', ' 89 White Second Avenue'),
(125, 71, ' r', 'Perspiciatis invent', ' Laboris repellendus', ' Aliquip in error ita', ' Iusto et veniam aut', ' Accusamus mollit ame', ' Voluptate sed animi'),
(126, 71, ' p', '713 Rocky Oak Street', ' 981 South Second Avenue', ' 376 Oak Parkway', ' 970 White Fabien Court', ' 123 White Hague Extension', ' 53 North Milton Parkway'),
(127, 72, ' r', 'Officia temporibus e', ' Pariatur Cupiditate', ' Voluptatem libero of', ' Dolorum praesentium ', ' Fugit ad qui ad et ', ' Et nihil vel autem e'),
(128, 72, ' p', '30 First Boulevard', ' 986 East White Cowley Lane', ' 21 White Second Extension', ' 666 Cowley Drive', ' 10 Cowley Drive', ' 715 Nobel Parkway'),
(129, 73, ' r', 'Officia temporibus e', ' Pariatur Cupiditate', ' Voluptatem libero of', ' Dolorum praesentium ', ' Fugit ad qui ad et ', ' Et nihil vel autem e'),
(130, 73, ' p', '30 First Boulevard', ' 986 East White Cowley Lane', ' 21 White Second Extension', ' 666 Cowley Drive', ' 10 Cowley Drive', ' 715 Nobel Parkway'),
(131, 74, ' r', 'Atque qui sit cillum', ' Quas cumque ea volup', ' Sit facere voluptas', ' Aute sit molestiae d', ' Doloremque qui sunt ', ' Omnis rem velit con'),
(132, 74, ' p', '86 East Old Boulevard', ' 21 East Rocky Nobel Parkway', ' 998 Clarendon Boulevard', ' 987 North Second Extension', ' 972 Old Court', ' 98 First Drive'),
(133, 75, ' r', 'Aperiam perferendis ', ' Duis sint id ipsam ', ' Saepe aut dolor volu', ' Placeat quibusdam c', ' Error magni iure fug', ' Modi rerum reprehend'),
(134, 75, ' p', '68 South White Old Avenue', ' 34 Milton Road', ' 339 First Freeway', ' 35 West Milton Freeway', ' 320 East Hague Court', ' 46 Milton Lane'),
(135, 76, ' r', 'Accusamus id totam ', ' Quia esse animi rep', ' Quasi quam nesciunt', ' Qui reprehenderit m', ' Cumque officia disti', ' Cumque nihil et mole'),
(136, 76, ' p', '287 South Green Second Drive', ' 31 West Milton Lane', ' 36 Second Lane', ' 39 Hague Extension', ' 73 White Milton Street', ' 306 First Parkway'),
(137, 77, ' r', '', ' ', ' Patiala', ' ', ' India', ' '),
(138, 77, ' p', '', ' ', ' ', ' ', ' ', ' '),
(139, 78, ' r', 'Tenetur obcaecati qu', ' Ab nisi recusandae ', ' Eaque unde magna fac', ' Numquam quo est dol', ' Eum cupidatat qui un', ' Ipsam sunt ullam vol'),
(140, 78, ' p', '90 Old Lane', ' 11 First Avenue', ' 827 North Second Street', ' 30 West Milton Street', ' 896 Milton Lane', ' 799 First Extension'),
(141, 79, ' r', 'Dolore dolor exercit', ' Rem aut accusantium ', ' Alias et voluptatem', ' Nulla et dolores mol', ' Adipisicing illum i', ' Doloremque aut dolor'),
(142, 79, ' p', '85 First Freeway', ' 346 New Lane', ' 756 White Oak Street', ' 76 Oak Boulevard', ' 98 West White Second Road', ' 903 South Cowley Road'),
(143, 80, ' r', 'Dolore dolor exercit', ' Rem aut accusantium ', ' Alias et voluptatem', ' Nulla et dolores mol', ' Adipisicing illum i', ' Doloremque aut dolor'),
(144, 80, ' p', '85 First Freeway', ' 346 New Lane', ' 756 White Oak Street', ' 76 Oak Boulevard', ' 98 West White Second Road', ' 903 South Cowley Road');

-- --------------------------------------------------------

--
-- Table structure for table `sliders`
--

CREATE TABLE `sliders` (
  `id` int(78) NOT NULL,
  `title` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `img` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `sliders`
--

INSERT INTO `sliders` (`id`, `title`, `url`, `description`, `img`, `status`) VALUES
(9, 'A PLACE TO MEET FRIENDS', 'http://localhost/meet/frontend/index.php', '  With Us, you can make friends from you same city                       ', 'user_1695917320.jpg', 1),
(10, 'Friendship - The Ultimate Team-Up', 'http://localhost/meet/frontend/index.php', '                                                                                                                                              Our friendship is a dynamic duo that always ready to tackle whatever life throws our way, just like iconic superh', 'user_1695272906.jpg', 1),
(11, 'Friends who slay together, stay together', 'http://localhost/meet/frontend/index.php', '                                                                                    Whether we are conquering challenges or simply enjoying each other s company, our friendship is unstoppable.                                                               ', 'user_1695272917.jpeg', 1),
(12, 'example 4', 'http://localhost/meet/frontend/index.php', '                                                                                    this is an example                                                                        ', 'user_1695272934.jpeg', 1),
(13, 'erfreg', 'frr', 'grgrg', 'user_1695368663.jpg', 0);

-- --------------------------------------------------------

--
-- Table structure for table `socials`
--

CREATE TABLE `socials` (
  `id` int(11) NOT NULL,
  `users_id` int(11) NOT NULL,
  `instagram` varchar(78) NOT NULL,
  `twitter` varchar(89) NOT NULL,
  `facebook` varchar(56) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `socials`
--

INSERT INTO `socials` (`id`, `users_id`, `instagram`, `twitter`, `facebook`) VALUES
(1, 1, 'us453', ' u3454', ' u345'),
(2, 2, '', '', ''),
(5, 17, 'user1', 'user1', 'user1'),
(6, 18, 'user1', 'user1', 'user1'),
(7, 19, 'er', 're', 'wre'),
(8, 20, 'reet', 'tert', 'reter'),
(9, 25, 'hjk', 'hjk', 'hjk'),
(14, 30, 'user1', '   user3', '   user2'),
(15, 31, 'instausers', '      twitterusers', '      facebookusersu'),
(16, 39, 'vasudha', 'vasudha', 'vasudha'),
(17, 40, 'vasudha', 'vasudha', 'vasudha'),
(18, 41, 'vasudha', 'vasudha', 'hb'),
(21, 44, 'vasudha', 'vasudha', 'vasudha'),
(22, 45, 'user1', 'user1', 'user1'),
(23, 46, 'user1', 'user1', 'user1'),
(24, 47, '', '', ''),
(27, 50, '', '', ''),
(28, 51, '', '', ''),
(29, 52, '', '', ''),
(30, 53, '', '', ''),
(31, 54, '', '', ''),
(32, 55, '', '', ''),
(33, 56, '', '', ''),
(34, 57, '', '', ''),
(35, 66, '', '', ''),
(38, 68, '', '', ''),
(39, 69, 'Vel accusamus ut mol', 'Consequatur obcaecat', 'Non eligendi in quid'),
(40, 70, 'Id ad velit dolorem', 'Quia similique commo', 'Laboriosam cupidata'),
(41, 71, 'Non nesciunt deseru', 'Dolorem officia dolo', 'Aute voluptas anim e'),
(42, 72, 'Hic eum nihil qui do', 'Dolorem omnis aliqui', 'Quo adipisci volupta'),
(43, 73, 'Hic eum nihil qui do', 'Dolorem omnis aliqui', 'Quo adipisci volupta'),
(44, 74, 'Ea vero exercitation', 'Est cillum aut ut en', 'Voluptatem magni aut'),
(45, 75, 'In proident delectu', 'Et impedit fugiat q', 'Commodi blanditiis r'),
(46, 76, 'Aliquip omnis nemo d', 'Officia cillum tenet', 'Architecto odit labo'),
(47, 77, '', '', ''),
(48, 78, 'Officiis laborum sed', 'Minus quia eaque vit', 'Error quam a praesen'),
(49, 79, 'Quia anim quo aliqua', 'A dolores est quo v', 'Est totam est non e'),
(50, 80, 'Quia anim quo aliqua', 'A dolores est quo v', 'Est totam est non e');

-- --------------------------------------------------------

--
-- Table structure for table `userreport`
--

CREATE TABLE `userreport` (
  `id` int(3) NOT NULL,
  `img` text NOT NULL,
  `reportid` int(11) DEFAULT NULL,
  `description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `is_admin` tinyint(255) DEFAULT 0,
  `id` int(5) NOT NULL,
  `name` varchar(24) NOT NULL,
  `phone` int(13) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(255) NOT NULL,
  `img` text NOT NULL,
  `gender` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL DEFAULT 'pending',
  `created at` datetime NOT NULL DEFAULT current_timestamp(),
  `modified_at` datetime DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`is_admin`, `id`, `name`, `phone`, `email`, `password`, `img`, `gender`, `status`, `created at`, `modified_at`) VALUES
(0, 1, 'Tanya Soni', 2147483647, 'tanyaert@bootesnull.com', '$2y$10$kv2HSjSiEPvNfn06Jb5kzuIC81OjkxaAPq0fFXpKEBKzdsBZ7pw2m', 'user_1693219253.png', 'female', 'REJECTED', '2023-08-26 20:02:04', '2023-09-28 21:45:38'),
(0, 2, 'tanya', 2147483647, 'tanya2@bootesnull.com', '$2y$10$.EsncY.K/6JHYVKBsOlequmIZJOCrmRWfEQ4dTpiDllGiZFv8dEr2', 'SangaMeet.png', 'female', 'APPROVED', '2023-08-26 20:03:52', '2023-09-22 14:51:03'),
(0, 3, 'mahima', 2147483647, 'mahima@bootesnull.com', '$2y$10$Srd5uI40lQ/hCqEipAq7me578LX0v8kbjPdwjF/tPHZldcyWKrxyW', 'SangaMeet.png', 'female', 'APPROVED', '2023-08-26 20:05:36', '2023-09-21 11:45:39'),
(0, 4, 'ram', 2147483647, 'ram@bootesnull.com', '$2y$10$kX9KSNHRilovgacIPz6Auu.KWaeAAo0FVN7fwzQ87OcPlD54q/WOK', ' ', 'male', 'PENDING', '2023-08-26 20:24:18', '2023-09-14 10:21:29'),
(0, 5, 'ram', 2147483647, 'ram1@bootesnull.com', '$2y$10$Rv6PPQqpHLSAqhEfUMB3PuRi1CAWlLvnXqf.oMe.2CCJ3kziUHOUK', ' user_1693061704.jpg', 'male', 'PENDING', '2023-08-26 20:25:04', '2023-09-14 10:21:29'),
(0, 17, 'Anshvi mallik', 2147483647, 'anshvimalik@bootesnull.com', '$2y$10$8lvbUWtn9XCoLi.nfwsO5OhBRRijQoNqYjmqFKK3ptefZWbMf97zi', ' user_1693216442.jpg', 'female', 'APPROVED', '2023-08-28 15:24:02', '2023-09-21 11:25:06'),
(0, 18, 'Anshvi mallik', 2147483647, 'rfghj@bootesnull.com', '$2y$10$rE4jj3OeF.VgqL/OUR8W.uXpzp21x5oIAhiXaX/2SGtoYKDGpJwh6', ' user_1693217420.jpg', 'female', 'APPROVED', '2023-08-28 15:40:20', '2023-09-21 11:26:27'),
(0, 19, '', 2147483647, 'erw@bootesnull.com', '$2y$10$GWMyoisSmEwRNO2EvW45o.6tNX/8zrj6V2AdnfVZlJ7HfOhAdbO5S', ' user_1693217510.', 'male', 'REJECTED', '2023-08-28 15:41:50', '2023-09-28 21:55:58'),
(0, 20, 'rewt', 2147483647, 'tany345a@bootesnull.com', '$2y$10$SSnDNVovKWB1dCTeCEuXQOC4qci9Qx5W0M0/J5BxUnntwDYsnX/ay', ' user_1693217543.png', 'male', 'PENDING', '2023-08-28 15:42:23', '2023-09-14 10:21:29'),
(0, 21, 'erty', 2147483647, 'tanya34@bootesnull.com', '$2y$10$52omf8O/IDtN5Nilx57/MeEClYUyvKWOKILIyDa778jamCYgAjWNq', ' user_1693217665.png', 'female', 'APPROVED', '2023-08-28 15:44:25', '2023-09-15 12:52:31'),
(0, 22, 'erty', 2147483647, 'tanya342345@bootesnull.com', '$2y$10$x3dFbuIfwC.LTqoI9GhcruFmqfeIxn.RaGuGBvQq0Wb3AiMDhbU5S', ' user_1693217716.png', 'female', 'APPROVED', '2023-08-28 15:45:16', '2023-09-21 11:45:17'),
(0, 23, 'erty', 2147483647, 'tanyewra342345@bootesnull.com', '$2y$10$copN3Q0thZI8e0BLIm2pvOfF9LCdqxBdLHygbeczDEPLOJP/i8zQ.', ' user_1693217761.png', 'female', 'APPROVED', '2023-08-28 15:46:01', '2023-09-21 11:45:03'),
(0, 24, 'erty', 2147483647, 'tanyewq3ra342345@bootesnull.co', '$2y$10$LptDlCeOK.LSY97XopUm9.cJqiizU3b8bAjDeJLlH/jm9UAmlsT9q', ' user_1693217808.png', 'female', 'APPROVED', '2023-08-28 15:46:48', '2023-09-21 11:45:26'),
(0, 25, 'erty', 2147483647, 'ta42345@bootesnull.com', '$2y$10$kGPDRYcKAfDC5nh4oRy37OnxPJwEcvX0eY.aYbFSp7byyW33LmOre', ' user_1693217855.png', 'female', 'APPROVED', '2023-08-28 15:47:35', '2023-09-21 11:45:06'),
(0, 29, '', 2147483647, 'tanywefa780@bootesnull.com', '$2y$10$q.a08/RK.dQyDo1YK5va2.Yu3xpI2uB919BB/l9cus3z0grcrwgsy', ' user_1693222285.', 'male', 'PENDING', '2023-08-28 17:01:25', '2023-09-28 21:46:15'),
(0, 30, 'Tanya soni', 2147483647, 'tanya0@bootesnull.com', '$2y$10$BMY13gv34ZTx1krxfh/1gOiXwFuyUTNHEMD1vVgM6WmGYlVkuPkEa', 'user_1693457006.png', 'male', 'PENDING', '2023-08-28 21:18:46', '2023-09-14 10:21:29'),
(1, 31, '    Tanya Soni ', 2147483647, 'tanyasoni276@bootesnull.com', '$2y$10$ycV36cA9nCsjKcq1XzB1FutV1OVmmd4vibqi2dThnL1EJ5eTKpUHG', 'user_1695360422.jpeg', 'male', 'APPROVED', '2023-09-01 10:52:32', '2023-09-22 10:57:02'),
(0, 32, 'Vasudha', 2147483647, 'vasudha123@gmail.com', '$2y$10$.M7F4UaQoCkHO.5LHg9IxuinIKfA8pkc0OXAwmsdEB38N4OtbR3FO', ' user_1693982660.png', 'female', 'APPROVED', '2023-09-06 12:14:20', '2023-09-28 18:39:19'),
(0, 33, 'Vasudha', 2147483647, 'vasudha123@bootesnull.com', '$2y$10$HP72SjL3ImqWWjCXRU0jP.74JkgWU0fy9PC5CYBEJgIIuTxacLYOu', ' user_1693982712.png', 'female', 'APPROVED', '2023-09-06 12:15:12', '2023-09-21 11:46:17'),
(0, 34, 'Vasudha', 2147483647, 'vasudha1233@bootesnull.com', '$2y$10$CdUc6KUO6FLUZAVtbW2Xku5lDXNaBdVba4qq62vjYO89ashK5/2y2', ' user_1693982864.png', 'female', 'APPROVED', '2023-09-06 12:17:44', '2023-09-21 11:48:21'),
(0, 35, 'Vasudha', 2147483647, 'vasudha573@bootesnull.com', '$2y$10$z0fYqpKfn3pNiBUFF.BGmOTodpCXwhcm1WAeIuFW114VqPwMGCyba', ' user_1693983095.png', 'female', 'PENDING', '2023-09-06 12:21:35', '2023-09-14 10:21:29'),
(0, 36, 'Vasudha', 2147483647, 'vasudha573ty@bootesnull.com', '$2y$10$jSOlG/PqNxdyErmOnM8Equ9cUdrTMYj87uBccXuoW.nm/gN2gyaAm', ' user_1693983133.png', 'female', 'PENDING', '2023-09-06 12:22:13', '2023-09-14 10:21:29'),
(0, 37, 'Vasudha', 2147483647, 'vasudha573sfrty@bootesnull.com', '$2y$10$Lg6oAd82ToNM8xJPK7yMEO2E7kXHZJ0FpkItp7.keIvSepEdXJvHC', ' user_1693983256.png', 'female', 'PENDING', '2023-09-06 12:24:16', '2023-09-14 10:21:29'),
(0, 38, 'Vasudha', 2147483647, 'vasudha5ty@bootesnull.com', '$2y$10$ivfno0N77m.UJu5GJ3ez/OlWyO3lH0t728PjxnxC7JaxadPcOeCmi', ' user_1693983271.png', 'female', 'PENDING', '2023-09-06 12:24:31', '2023-09-14 10:21:29'),
(0, 39, 'Vasudha', 2147483647, 'vasudha589@bootesnull.com', '$2y$10$xgU.XOIhXIXQajlaDmnaSeTyXNWA.argZDEXrKPMLp5M974pouxJC', ' user_1693983482.png', 'female', 'PENDING', '2023-09-06 12:28:02', '2023-09-14 10:21:29'),
(0, 40, 'Tanya ', 2147483647, 'jairi234@bootesnull.com', '$2y$10$/iIHOH/P1WZarxpY1edXc.lmxSryrY9wIxBjNt5phq6FiPTFfW7I.', ' user_1693984282.', 'male', 'PENDING', '2023-09-06 12:41:22', '2023-09-14 10:21:29'),
(0, 41, 'wergrfds', 2147483647, 'gauri12r33@gmail.com', '$2y$10$6FgM2pteXCpVfGN6fMRXyOTvGWLoPdg2abPJ9vnSjLIPi4onr57zK', ' user_1693984325.', 'male', 'APPROVED', '2023-09-06 12:42:06', '2023-09-28 18:38:51'),
(0, 44, 'shilpa', 2147483647, 'sr3911205@gmail.com', '$2y$10$o6XLSGIVhhyV3/IX3a8cGenKaUSKAgD74htW5HNs0blymJtehfGLC', ' user_1694407455.png', 'male', 'PENDING', '2023-09-11 10:14:15', '2023-09-14 10:21:29'),
(0, 45, 'Himani', 2147483647, 'Himani@bootesnull.com', '$2y$10$KWe3UuHyik9DNlVtiwVYDO5Q5bVnnW9g2N74paO7FpgjmVQl7.exi', ' user_1694588286.jpeg', 'male', 'APPROVED', '2023-09-13 12:28:06', '2023-09-21 11:45:11'),
(0, 46, 'Himani', 2147483647, 'harshita@bootesnull.com', '$2y$10$t/CCzHbygnJSyDMAHHZBPuBV2Ny4SLRzJNhOkJfxPyg/C7FtzokbS', ' user_1694588534.jpeg', 'male', 'APPROVED', '2023-09-13 12:32:14', '2023-09-21 11:45:10'),
(0, 47, 'abc', 2147483647, 'abc@bootesnull.com', '$2y$10$OM4eS8qepWoa6KiYCJ/gNO47ama1w9jCOFoK0XynKfxSf.DMUlpW2', ' user_1694666653.', 'male', 'APPROVED', '2023-09-14 10:14:13', '2023-09-22 13:10:20'),
(0, 50, 'Tanya ', 2147483647, 'anshvimalik7617@gmail.com', '$2y$10$dIT.MY7Sn7IFPsxdN6giPu/qO2Qsa5fRMw.yydvzqtdfo1VHfTg2a', ' user_1694687788.', 'male', 'pending', '2023-09-14 16:06:28', NULL),
(0, 51, 'anshvi', 2147483647, 'anshvi7617malik@gmail.com', '$2y$10$68QM3WlIRNqumko6lkzcjOKM5ppdMbiNpsQ5VvNswh0uMLIR556KK', ' user_1694760634.', 'male', 'APPROVED', '2023-09-15 12:20:34', '2023-09-28 21:44:38'),
(0, 52, '', 2147483647, 'abhc@bootesnull.com', '$2y$10$ofiJQxvj/EFMEtYq5YTX1uHcd1pK6Yf8uKoFkOg6gwiwENSoh4S7i', ' user_1694762357.', 'male', 'PENDING', '2023-09-15 12:49:17', '2023-09-28 21:46:18'),
(0, 53, '', 2147483647, 'abhoc@bootesnull.com', '$2y$10$HVcmtYC6HTaYnySvpyYZuOXW9EhSlz3V4FOzzEP3Uzf/Xm7p80jJW', ' user_1694762463.', 'male', 'PENDING', '2023-09-15 12:51:03', '2023-09-28 21:46:20'),
(0, 54, 'Tanya ', 2147483647, 'abhoc45@bootesnull.com', '$2y$10$BwqQWNwqm/Livxw98jofEO60MGC6IOp9dgLnF3KTWSXjiUENG.h26', ' user_1694762502.', 'male', 'pending', '2023-09-15 12:51:42', NULL),
(0, 55, '', 2147483647, 'here@bootesnull.com', '$2y$10$9UNN0R8JGgYaVa/Cs8nUpO9BGYtb1eIhG6nw3bSb2hDNmjcMmNq3u', ' user_1694763492.', 'male', 'APPROVED', '2023-09-15 13:08:12', '2023-09-21 10:46:56'),
(0, 56, 'Tanya ', 2147483647, 'tanya1234@bootesnull.com', '$2y$10$wzb5PRInXaMZd/MnbEIv6uqoTM3oXmi0nrIQ03fwZhP4hNymrVUbS', ' user_1694764536.', 'male', 'pending', '2023-09-15 13:25:36', NULL),
(0, 57, 'user1', 2147483647, 'person1@bootesnull.com', '$2y$10$lXuSeAhP1onWJnlDgjuJQO19EzBLniA6fRCHqZBtGDCyzPyfE2sce', ' user_1694794874.webp', 'male', 'pending', '2023-09-15 21:51:14', NULL),
(0, 58, 'priyapal', 2147483647, 'tanya@gmail.com', '$2y$10$4sDuu4zEUfuGDbbz09REYO2QtIwO87ZSEi2MIz047K1kYCs9HqciO', '', '', 'pending', '2023-09-17 15:30:55', NULL),
(0, 60, 'priyapal', 1234567890, 'tanyasontghjpm@bootesnull.com', '$2y$10$VoNhsBWtqdjhAGE77xQnCesrBgSPWfIV8dBBKV6AqhB.UL64ulKQi', '', '', 'APPROVED', '2023-09-17 15:31:58', '2023-09-28 21:15:27'),
(0, 61, '', 989759647, 'mahima@gmail.com', '$2y$10$nzmaTaeP9Seq6i8NJCd2b.nmOT76zQkCZnCHfWv5jExIt0sni/OJy', '', '', 'APPROVED', '2023-09-17 15:32:28', '2023-09-21 11:13:17'),
(0, 65, 'we', 989759647, 'mahimwea@gmail.com', '$2y$10$ADwfgU26PIw6Ns12PUNd2edBvK.whiJfjgbkTPtOCUPvC1bwIDqIW', '', '', 'APPROVED', '2023-09-17 15:33:04', '2023-09-28 18:39:03'),
(0, 66, '', 2147483647, 'tanya1245@gmail.com', '$2y$10$OQ7ii6fNFXssSlyExqBXY.QJA3r14tM6OKveW5ckYKO35wK54E6.i', ' user_1694950648.', 'male', 'APPROVED', '2023-09-17 17:07:28', '2023-09-21 11:14:58'),
(0, 68, 'Tanya ', 2147483647, 'tfgtrr@gmail.com', '$2y$10$TYfWO1eFlSTo4JWXij5y2.bv91tqAP4h3wPAfSL9/fZzIiHLiiW2a', ' user_1695022032.jpeg', '', 'pending', '2023-09-18 12:57:12', NULL),
(0, 69, 'Constance Mcconnell', 1, 'dedekawore@mailinator.com', '$2y$10$CI11fJewFhdhKpzmJd5jNeAyywraWRCEON.2TA6g1aqzVm1BS4XAW', 'user_1695206280.jpg', 'female', 'APPROVED', '2023-09-20 16:08:00', '2023-09-21 11:45:01'),
(0, 70, 'Steel Saunders', 1, 'zacysupy@mailinator.com', '$2y$10$xKFNh9j03717HSirKOQJJ.qW1TWesVynUjp6oLQ/WNM3vXCXcxLtK', 'user_1695269041.jpg', 'male', 'pending', '2023-09-21 09:34:01', NULL),
(0, 71, 'Roanna Guzman', 1, 'zoxoly@mailinator.com', '$2y$10$U7I.3lqzUy6to3c8jYkZ3udeVBw7D9jInuNFReOSwJXOpmdDx2ti.', 'user_1695271878.jpg', 'male', 'pending', '2023-09-21 10:21:19', NULL),
(0, 72, 'Quentin Tillman', 1, 'difaha@mailinator.com', '$2y$10$xFczTRCIl2HiH2O/oFgOReVEYhXEmRHQEZnq4CZFOBONo4ulBvjiO', 'user_1695271918.jpg', 'female', 'pending', '2023-09-21 10:21:58', NULL),
(0, 73, 'Quentin Tillman', 1, 'tfg@mailinator.com', '$2y$10$QMeoguhC3SnDQQ8GXgEG9.me01sBLs.4/1veA593uIzXZEWYWc2V.', 'user_1695271935.jpg', 'female', 'pending', '2023-09-21 10:22:15', NULL),
(0, 74, 'Jena Stokes', 1, 'jena@gmail.com', '$2y$10$ea/xV1LHXwJE6Y11e84fHOXTwdg2p5Kr33UY15zEiVfOBObQ04TOC', 'user_1695282127.jpeg', 'male', 'pending', '2023-09-21 13:12:08', NULL),
(0, 75, 'Madonna Gregory', 1, 'konicopi@mailinator.com', '$2y$10$mc.SPgD8OTKGNhJtwxH47OtkrvYAdIV7TSwWLcubuUChxY/JtNrQq', 'user_1695616273.jpeg', 'male', 'pending', '2023-09-25 10:01:13', NULL),
(0, 76, 'Grace Vincent', 2147483647, 'txyz123@gmail.com', '$2y$10$iy9AxPjhRRxq7JYT6mq.xePtKez3v2Svk5olm66kY2BUUvsiIkcwu', 'user_1695906717.jpg', 'female', 'pending', '2023-09-28 18:41:57', NULL),
(0, 77, 'Tanya ', 2147483647, 'tanyasoni@gmail.com', '$2y$10$E7rgEj/LyIlLitGBjovTKu/dXdjradSvQJ5MEbbBvUI2LAL5hXub6', 'user_1695915372.png', 'male', 'APPROVED', '2023-09-28 21:06:13', '2023-09-28 21:08:29'),
(0, 78, 'Kellie Morse', 1, 'vaditi657@gmail.com', '$2y$10$XDwoIPjMsOn4UU3fX1JpgOBM1xdlVqHPOxLcJRk7OgCMu.wmHC/tm', 'user_1695916763.jpeg', 'male', 'APPROVED', '2023-09-28 21:29:23', '2023-09-28 21:31:31'),
(0, 79, 'Stacey Levy', 1, 'dene@mailinator.com', '$2y$10$JmCe2F/XJm8SlsKD4baUS.Fis41jEgXj9OiiiIAhe.3BTaHATWhXi', 'user_1695919215.', 'male', 'pending', '2023-09-28 22:10:15', NULL),
(0, 80, 'Stacey Levy', 1, 'tanyasoni276@gmail.com', '$2y$10$1yjF7IS.QmpbFFSaOZ3oi.U2H6RfW.bkMrWm869RocGWa7U4KH7Dq', 'user_1695919849.', 'male', 'pending', '2023-09-28 22:20:49', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_id` (`users_id`);

--
-- Indexes for table `sliders`
--
ALTER TABLE `sliders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `socials`
--
ALTER TABLE `socials`
  ADD PRIMARY KEY (`id`),
  ADD KEY `users_id` (`users_id`);

--
-- Indexes for table `userreport`
--
ALTER TABLE `userreport`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` int(67) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT for table `sliders`
--
ALTER TABLE `sliders`
  MODIFY `id` int(78) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `socials`
--
ALTER TABLE `socials`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT for table `userreport`
--
ALTER TABLE `userreport`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=81;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `addresses`
--
ALTER TABLE `addresses`
  ADD CONSTRAINT `addresses_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `socials`
--
ALTER TABLE `socials`
  ADD CONSTRAINT `socials_ibfk_1` FOREIGN KEY (`users_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
