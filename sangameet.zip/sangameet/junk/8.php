<div class="mb-3">
                    <label>Name</label>
                    <input type="text" class="form-control" id="exampleFormControlInput2" placeholder="username" value="<?php { echo $rows['name']; } ?>" name="name" >
                  </div>
                  <div class="mb-3">
                  <label for="exampleFormControlInput3" class="form-label">Email</label>
                  <input type="email" class="form-control" id="exampleFormControlInput3" placeholder="name@example.com"     value="<?php if(isset($rows['email'])) { echo $rows['email']; } ?>"  name="email" readonly>
                  </div>
                  <div class="mb-3">
                  <label for="exampleFormControlInput4" class="form-label">PhoneNumber</label>
                  <input type="text" class="form-control" id="exampleFormControlInput4" placeholder="enter the phone number"  value="<?php if(isset($rows['phone'])) { echo $rows['phone']; } ?>" name="phone" >
                  </div> 
                  <div class="column">
                        <?php $addresses = ["r"=>"Residential Address","p"=>"Permanent Address"];
                          $i = 0;
                          foreach ($addresses as $key=>$address) {
                          $type = "addr[$i][type]";
                        ?>
                        <label class="form-label"><?php echo $address ?></label>
                        <input type="hidden" name="<?php echo $type; ?>" value="<?php echo $key; ?>">
                        <input type="hidden" name="addr[<?php echo $i ?>][address_id]" value="<?php if(isset($filterData[$i]['id'])){echo $filterData[$i]['id'];}?>">
                        <input type="text" placeholder="Enter house no "  name="addr[<?php echo $i ?>][house]" value="<?php if(isset($filterData[$i]['house'])){echo $filterData[$i]['house'];}?>"/>
                        <input type="text" placeholder="Enter street address"  name="addr[<?php echo $i ?>][street]" value="<?php echo $filterData[$i]['street'];?>"/>
                        <input type="text" placeholder="Enter your city" name="addr[<?php echo $i ?>][city]" value="<?php echo $filterData[$i]['city'];?>"/>
                        <input type="text" placeholder="Enter your state"  name="addr[<?php echo $i ?>][state]"value="<?php echo $filterData[$i]['state'];?>"/> 
                        <input type="text" placeholder="Enter pincode " name="addr[<?php echo $i ?>][pincode]" value="<?php echo $filterData[$i]['pincode'];?>" >
                        <input type="text" placeholder="Enter your country " name="addr[<?php echo $i ?>][country]"value="<?php echo $filterData[$i]['country'];?>"/>
                        <?php
                          $i++;
                          }
                        ?>
                  </div>
                  <div class="input-box">
                              <label>Social media (if any)</label>
                              <input type="text" placeholder="Enter Instagram Profile " name="instagram"  value="<?php if(isset($rows['instagram'])) {  echo $rows['instagram']; } ?>"  >
                              <input type="text" placeholder="Enter Facebook Profile"name="facebook"  value="<?php echo $rows['facebook'] ;?>">
                              <input type="text" placeholder="Enter your Twitter Profile " name="twitter" value="<?php echo $rows['twitter'] ;?>">
                  </div>
                  <button type="submit" name="update" class="btn btn-block btn-primary" >Confirm</button>
                 <?php    
                     }
                   ?> 



dcfvbnm,<div class=""
<?php
                     } 
                     $filterData = [];
                     $s = 0;
                     foreach( $data as $rows)
                     {      
                     // echo $rows['house'];
                     $filterData[$s]['house'] = $rows['house'];
                     $filterData[$s]['street'] = $rows['street'];
                     $filterData[$s]['city'] = $rows['city'];
                     $filterData[$s]['state'] = $rows['state'];
                     $filterData[$s]['pincode'] = $rows['pincode'];
                     $filterData[$s]['country'] = $rows['country'];
                     $filterData[$s]['id'] = $rows['id'];
                     $s++;
                     }
                  ?>
                  <div class="mb-3">
                     <label for="exampleFormControlInput1" class="form-label">Profile</label>
                     <input type="file" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com"  name="img" class="img">
                     <input type="hidden" value="<?php {echo $rows['users_id'] ; }?>" name="users_id" /> 
                  </div>
          
                  <div class="mb-3">
                    <label>Name</label>
                    <input type="text" class="form-control" id="exampleFormControlInput2" placeholder="username" value="<?php { echo $rows['name']; } ?>" name="name" >
                  </div>
                  <div class="mb-3">
                  <label for="exampleFormControlInput3" class="form-label">Email</label>
                  <input type="email" class="form-control" id="exampleFormControlInput3" placeholder="name@example.com"     value="<?php if(isset($rows['email'])) { echo $rows['email']; } ?>"  name="email" readonly>
                  </div>
                  <div class="mb-3">
                  <label for="exampleFormControlInput4" class="form-label">PhoneNumber</label>
                  <input type="text" class="form-control" id="exampleFormControlInput4" placeholder="enter the phone number"  value="<?php if(isset($rows['phone'])) { echo $rows['phone']; } ?>" name="phone" >
                  </div> 
                  <div class="column">
                        <?php $addresses = ["r"=>"Residential Address","p"=>"Permanent Address"];
                          $i = 0;
                          foreach ($addresses as $key=>$address) {
                          $type = "addr[$i][type]";
                        ?>
                        <label class="form-label"><?php echo $address ?></label>
                        <input type="hidden" name="<?php echo $type; ?>" value="<?php echo $key; ?>">
                        <input type="hidden" name="addr[<?php echo $i ?>][address_id]" value="<?php if(isset($filterData[$i]['id'])){echo $filterData[$i]['id'];}?>">
                        <input type="text" placeholder="Enter house no "  name="addr[<?php echo $i ?>][house]" value="<?php if(isset($filterData[$i]['house'])){echo $filterData[$i]['house'];}?>"/>
                        <input type="text" placeholder="Enter street address"  name="addr[<?php echo $i ?>][street]" value="<?php echo $filterData[$i]['street'];?>"/>
                        <input type="text" placeholder="Enter your city" name="addr[<?php echo $i ?>][city]" value="<?php echo $filterData[$i]['city'];?>"/>
                        <input type="text" placeholder="Enter your state"  name="addr[<?php echo $i ?>][state]"value="<?php echo $filterData[$i]['state'];?>"/> 
                        <input type="text" placeholder="Enter pincode " name="addr[<?php echo $i ?>][pincode]" value="<?php echo $filterData[$i]['pincode'];?>" >
                        <input type="text" placeholder="Enter your country " name="addr[<?php echo $i ?>][country]"value="<?php echo $filterData[$i]['country'];?>"/>
                        <?php
                          $i++;
                          }
                        ?>
                  </div>
                  <div class="input-box">
                              <label>Social media (if any)</label>
                              <input type="text" placeholder="Enter Instagram Profile " name="instagram"  value="<?php if(isset($rows['instagram'])) {  echo $rows['instagram']; } ?>"  >
                              <input type="text" placeholder="Enter Facebook Profile"name="facebook"  value="<?php echo $rows['facebook'] ;?>">
                              <input type="text" placeholder="Enter your Twitter Profile " name="twitter" value="<?php echo $rows['twitter'] ;?>">
                  </div>
                  <button type="submit" name="update" class="btn btn-block btn-primary" >Confirm</button>
                 <?php    
                     }
                   ?> 



 <!---- acordion start --->
      <ul class="acordion">
         <li>
            <input type="radio" name="acordion" id="first">
            <label for="first" class="hlabel">Profile</label>
            <div class="content">
              <form action="controller/UserController.php" method="POST" enctype="multipart/form-data">
                  <?php 
                     if($data)
                     {
                             $file_name = $data[0]['img'];
                             //echo $file_name;
                                 if($file_name == NULL)
                                 {
                                     echo'<img src="">';
                                 }else{
                                   $imgUrl = "image/".trim($file_name);
                                 //  echo $imgUrl;
                                   ?>
                  <div class="center"><img class="profile" src="<?php echo $imgUrl; ?>"></div>
                  <?php
                     } 
                     $filterData = [];
                     $s = 0;
                     foreach( $data as $rows)
                     {      
                     // echo $rows['house'];
                     $filterData[$s]['house'] = $rows['house'];
                     $filterData[$s]['street'] = $rows['street'];
                     $filterData[$s]['city'] = $rows['city'];
                     $filterData[$s]['state'] = $rows['state'];
                     $filterData[$s]['pincode'] = $rows['pincode'];
                     $filterData[$s]['country'] = $rows['country'];
                     $filterData[$s]['id'] = $rows['id'];
                     $s++;
                     }
                  ?>
                  <div class="mb-3">
                     <label for="exampleFormControlInput1" class="form-label">Profile</label>
                     <input type="file" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com"  name="img" class="img">
                     <input type="hidden" value="<?php {echo $rows['users_id'] ; }?>" name="users_id" /> 
                  </div>
          
                  <div class="mb-3">
                    <label>Name</label>
                    <input type="text" class="form-control" id="exampleFormControlInput2" placeholder="username" value="<?php { echo $rows['name']; } ?>" name="name" >
                  </div>
                  <div class="mb-3">
                  <label for="exampleFormControlInput3" class="form-label">Email</label>
                  <input type="email" class="form-control" id="exampleFormControlInput3" placeholder="name@example.com"     value="<?php if(isset($rows['email'])) { echo $rows['email']; } ?>"  name="email" readonly>
                  </div>
                  <div class="mb-3">
                  <label for="exampleFormControlInput4" class="form-label">PhoneNumber</label>
                  <input type="text" class="form-control" id="exampleFormControlInput4" placeholder="enter the phone number"  value="<?php if(isset($rows['phone'])) { echo $rows['phone']; } ?>" name="phone" >
                  </div> 
                  <div class="column">
                        <?php $addresses = ["r"=>"Residential Address","p"=>"Permanent Address"];
                          $i = 0;
                          foreach ($addresses as $key=>$address) {
                          $type = "addr[$i][type]";
                        ?>
                        <label class="form-label"><?php echo $address ?></label>
                        <input type="hidden" name="<?php echo $type; ?>" value="<?php echo $key; ?>">
                        <input type="hidden" name="addr[<?php echo $i ?>][address_id]" value="<?php if(isset($filterData[$i]['id'])){echo $filterData[$i]['id'];}?>">
                        <input type="text" placeholder="Enter house no "  name="addr[<?php echo $i ?>][house]" value="<?php if(isset($filterData[$i]['house'])){echo $filterData[$i]['house'];}?>"/>
                        <input type="text" placeholder="Enter street address"  name="addr[<?php echo $i ?>][street]" value="<?php echo $filterData[$i]['street'];?>"/>
                        <input type="text" placeholder="Enter your city" name="addr[<?php echo $i ?>][city]" value="<?php echo $filterData[$i]['city'];?>"/>
                        <input type="text" placeholder="Enter your state"  name="addr[<?php echo $i ?>][state]"value="<?php echo $filterData[$i]['state'];?>"/> 
                        <input type="text" placeholder="Enter pincode " name="addr[<?php echo $i ?>][pincode]" value="<?php echo $filterData[$i]['pincode'];?>" >
                        <input type="text" placeholder="Enter your country " name="addr[<?php echo $i ?>][country]"value="<?php echo $filterData[$i]['country'];?>"/>
                        <?php
                          $i++;
                          }
                        ?>
                  </div>
                  <div class="input-box">
                              <label>Social media (if any)</label>
                              <input type="text" placeholder="Enter Instagram Profile " name="instagram"  value="<?php if(isset($rows['instagram'])) {  echo $rows['instagram']; } ?>"  >
                              <input type="text" placeholder="Enter Facebook Profile"name="facebook"  value="<?php echo $rows['facebook'] ;?>">
                              <input type="text" placeholder="Enter your Twitter Profile " name="twitter" value="<?php echo $rows['twitter'] ;?>">
                  </div>
                  <button type="submit" name="update" class="btn btn-block btn-primary" >Confirm</button>
                 <?php    
                     }
                   ?> 
            </form>
          </li>
       </ul>
    <!---- acordion end --->