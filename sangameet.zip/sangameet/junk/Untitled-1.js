<script>
$(document).ready(function(){
	// console.log("submit");
    {/* method 1 */}
	//$("#submit").on('click', function(e){
    $('#register').submit(function(e) {
        e.preventDefault();
         
        //var formData = new FormData(this);
        var formData = new FormData(this);
        formData.append('formAjax','true');
        // console.log(formData);
        // return false;
 /* method 2 */
        // var formData = $(this).serialize();
        // formData += '&formAjax=true'; 
        // var fileInput = $('.file')[0]; // Convert jQuery object to a DOM element
        // var file = fileInput.files[0]; // Access the selected file
        
        // console.log(file);  


        //console.log(formData);
        //return false;
 /* method 3 */
	// $("button[name='submit']").on('click',function(){
		/*console.log("yes");
		e.preventDefault();
        var fileInput = $('.file')[0]; // Convert jQuery object to a DOM element
        var file = fileInput.files[0]; // Access the selected file
        
        console.log(file);      
        //   var file = $('.file').files[0];
        var form = new FormData();
        // var file =$('.file').val();
        form.append('formAjax', 'true');
        form.append('img', file);
        form.append('name', $('.name').val());
        form.append('email', $('.email').val());
        form.append('password', $('.password').val());
        form.append('phone', $('.phone').val());
        form.append('gender', $('.gender').val());
        form.append('instagram', $('.insta').val());
        form.append('facebook', $('.facebook').val());
        form.append('twitter', $('.twitter').val());

      

        for (var i = 0; i <= 1; i++) {

            var type = $('.type_' + i).val();
            var house = $('.house_' + i).val();
            var street = $('.street_' + i).val();
            var city = $('.city_' + i).val();
            var state = $('.state_' + i).val();
            var pincode = $('.pincode_' + i).val();
            var country = $('.country_' + i).val();

            // Append the values to the FormData object

            form.append('address[' + i + '][type]', type);
            form.append('address[' + i + '][house]', house);
            form.append('address[' + i + '][street]', street);
            form.append('address[' + i + '][city]', city);
            form.append('address[' + i + '][state]', state);
            form.append('address[' + i + '][pincode]', pincode);
            form.append('address[' + i + '][country]', country);

        }*/


        $.ajax({
			url:'controller/Usercontroller.php',
			type:'POST',
            // cache: false,
            contentType: false,
            processData: false,
			data: formData,
			success:function(response){
				console.log(response);
                return false;
                var parse_data = JSON.parse(response);
				console.log(parse_data);
                
                alert(parse_data.message);
                
				// $('#response').html(parse_data.message);
				// $('#response').show(parse_data.message);
                // $("#response").delay(5000).fadeOut();
	
			},
		});

	});
});
</script>