<?php
	
	include "C:/xampp/htdocs/meet/connection.php";
	include "C:/xampp/htdocs/meet/vendor/autoload.php";
	use PHPMailer\PHPMailer\PHPMailer;
	use PHPMailer\PHPMailer\SMTP;
	use PHPMailer\PHPMailer\Exception;
  class Usercontroller 
  {
	public  function insertintousers($name,$phone,$email,$password,$gender,$file_name,$obj1)
	{    
		echo "here2";
		$mail = new PHPMailer(true);
		$hashedPassword = password_hash($password,PASSWORD_BCRYPT);
		$sql = "SELECT * FROM users WHERE email='$email'";
		$result = mysqli_query($obj1->connect(), $sql);
		$row_count = mysqli_num_rows($result);
			if ($row_count != 0)
			{
				$response = array(
				"success" => false,
				"message" => "This email id is already registered with us!"
			);
			echo json_encode($response);
			exit;
			}
			
		if(preg_match('/^[7-9][0-9]{9}+$/',$phone) && (filter_var($email, FILTER_VALIDATE_EMAIL)))
		{	echo "here3";
		
			$sql1 = "INSERT INTO users (name,phone,email,password,gender,img) VALUES ('$name','$phone','$email', '$hashedPassword','$gender',' $file_name')";
			
			$result1 = mysqli_query($obj1->connect(), $sql1);
			if ($result1)
			{
				$getid =$this-> getUserId($email,$obj1);
				if($getid)
				{
					$add= $this->insertAddress($addresses,$userId,$obj1);
					if($add)
					{
                      $add2= $this-> insertintosocials($instagram,$facebook,$twitter,$userId,$obj1);
					  if($add2)
					  {
						 $response = array("success" => true, "message" => "creation done!"); 
						echo json_encode($response);
						header("Location:../index.php");
					  }
					}
				}	
			}
		}else
		{
			echo"Invalid Email and Phone format";
		}
		
	
		try {
		//Server settings
		$mail->SMTPDebug = false;                      
		$mail->isSMTP();                                            
		$mail->Host       = 'smtp.gmail.com';                    
		$mail->SMTPAuth   = true;                                   
		$mail->Username   = 'tanyasoni276@gmail.com';                    
		$mail->Password   = 'qgammrizjagwvyfq';                               
		$mail->SMTPSecure = 'tls';           
		$mail->Port       = 587;                                	
		$mail->setFrom('tanyasoni276@gmail.com','meet');
		$mail->addAddress($email, 'new member');    
		$mail->isHTML(true);                               
		$mail->Subject = 'New Member Registration';
		$mail->Body    = 'Thank You for registration';
		$mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

		$mail->send();
			echo 'Message has been sent';
		} catch (Exception $e) {
			echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
		}	
		//
	}
	function getUserId($email,$obj1)
	{
		echo $email;
		$sql3="SELECT id FROM users WHERE email = '$email'";
		$result3 = mysqli_query($obj1->connect(), $sql3);	
		$num=mysqli_num_rows($result3);
		if($num==1)
		{
			$row=mysqli_fetch_assoc($result3);
			$users_id = $row['id'];
		  echo $users_id;
			return $users_id;
		}
	}
	public function insertAddress($addresses,$userId,$obj1)
	{
		
		echo "<pre>";print_r($addresses);
		foreach ($addresses as $address)
		{
		    $house = $address["house"];
		    $street = $address["street"];
		    $city = $address["city"];
		    $state = $address["state"];
		    $pincode = $address["pincode"];
		    $country = $address["country"];
		    $type = $address["type"];
			$sql4 = "INSERT INTO addresses(house,street,city,state,pincode,country,type,users_id) VALUES('$house',' $street',' $city',' $state',' $pincode',' $country',' $type','$userId')";
			$result4 = mysqli_query($obj1->connect(), $sql4);
			if (!$result4)
			{
				$response = array("success" => false, "message" => "Something went wrong!");
				echo json_encode($response);
				return;
			}else
			{	
				$response = array( "success" => true,"message" => "Your account has been created successfully!");
				echo json_encode($response);
			}
			
		}
		
	}
	public function insertintosocials($instagram,$facebook,$twitter,$userId,$obj1)
	{
		$obj=new Connection();
		
		$sql5 = "INSERT INTO socials(instagram,facebook,twitter,users_id) VALUES ('$instagram','$facebook','$twitter','$userId')";
		$result5 = mysqli_query($obj->connect(), $sql5);
		if ($result5)
		{
			$response = array( 

			"success" => true,
			"message" => "Your account has been created successfully!"
			);
			echo json_encode($response);
		}
	}
	public function logIn($email,$requestPassword,$obj1)
	{
		$sql="SELECT * FROM users WHERE email='$email'";
		$result=mysqli_query($obj->connect(),$sql);
		$num=mysqli_num_rows($result);
		//print_r($num); die;
		if($num==1)
		{  $error =" "; 
			$row=mysqli_fetch_assoc($result);
			$hashedpassword=$row['password'];
			// echo $hashedpassword;	
			if(password_verify($requestPassword,$hashedpassword))
			{
				session_start();
				// echo "yes";
				if(isset($_SESSION['error']) && !isset($_SESSION['id'])){
					unset($_SESSION['error']); 
				}
				$_SESSION['id']=$row['id'];
				$_SESSION['name'] = $row['name'];
				$_SESSION['email'] = $row['email'];
				// echo "<pre>";print_r($_SESSION); die;
				header("Location:../index.php");
			}else{
				$_SESSION['error'] = "Password does not match!"; 
				header("Location:../index.php");
			}
		
							
		}
		
	}
	public function displayData($user_id,$obj1)
	{   $sql_1 = "SELECT *
		FROM users
		JOIN socials ON users.id = socials.users_id
		JOIN addresses ON users.id = addresses.users_id
		WHERE users.id = $user_id";
 		$result_1 = mysqli_query($obj1->connect(), $sql_1);
		if($result_1->num_rows > 0)
		{ 
			$num_rows=$result_1->num_rows;
			while($row = $result_1->fetch_assoc())
			{
				$data[]=$row;
			} 
		}
		
		return $data;

	}
	public function updateAddress($data,$obj1)
	{
		try {
			echo"<pre>";print_r($data);
			foreach($data['addr'] as $val){
	         $id = $val['address_id'];
	         $street = $val['street'];
			$house=$val['house'];
			$city=$val['city'];
			$state=$val['state'];
			$pincode=$val['pincode'];
			$country=$val['country'];
			$sql = "UPDATE addresses SET house='$house',city='$city', state='$state',pincode='$pincode',country='$country',street= '$street' WHERE id= $id";
			$res= $obj1->connect()->query($sql);
			}
			return true;
		} catch (\Throwable $th) {
			echo "<pre>";print_r($th);die;
			return false;
		}
	}
	public function update($data,$file_name,$obj1)
	{   
		$name =$_POST['name'];
        $phone =$_POST['phone'];
        $users_id =$_POST['users_id'];
        $email =$_POST['email'];
		$sql="UPDATE users SET name='$name',phone='$phone',img = '$file_name'WHERE id=$users_id";
		$res= $obj1->connect()->query($sql);
		if($res === true)
		{ 
			$updateAdd = $this->updateAddress($data,$obj1);
			if($updateAdd){
				echo "Successs";
			}
		}else{
			die("failed");
		}
	}
	public function uploadImage($file_name)
	{
		$file_name_array =explode(".", $file_name);
		$extention = end($file_name_array);
		//here to store a new name for a file 
		$new_image_name = 'user_'.time().'.'.$extention;
		echo $new_image_name; 
		
		if($_FILES['img']['size'] >1000000){
			$error[]="Sorry, your image is tooo large.Upload less than 1Mb in size";

		}
		
		if($file_name != "")
		{
			if($extention!="jpg" &&  $extention!="png"  && $extention!="jpeg" && $extention!="gif" &&$extention!="PNG" && $extention!="JPG" &&$extention!="GIF" && $extention!="JPEG" ){
			$error[]="Sorry ,only JPG,JPEG,PNG & GIF files are allowed";
			}
		}
		return($new_image_name);
	}
}

if(isset($_POST['submit']))
{
		$obj = new Usercontroller();
		$obj1=new Connection();
		$file_name = $_FILES['img']['name']; 
		$file_tmp=$_FILES['img']['tmp_name'];
		$file_name1=$obj->uploadImage($file_name);
		echo $file_name1;
		move_uploaded_file($file_tmp,"../image/".$file_name1); 
		$obj->insertintousers($_POST['name'],$_POST['phone'],$_POST['email'],$_POST['password'], $_POST['gender'],$file_name1,$obj1);
		$userId=$obj->getUserId($_POST['email'],$obj1);
		print_r($userId); 
		$submit=$_POST;
		 echo"<pre>";print_r($submit);
		$addresses=$_POST['address'];
		//  echo"<pre>";print_r($addresses);
		$obj->insertAddress($addresses,$userId,$obj1);
		$obj->insertintosocials($_POST['instagram'],$_POST['facebook'],$_POST['twitter'],$userId,$obj1);
}
if(isset($_POST['login']))
{
	
	$obj = new Usercontroller();
	$obj1=new Connection();
	$obj->logIn($_POST['email'],$_POST['password'],$obj1);
}
if(isset($_POST['update']))
{
	$obj1=new Connection();
	$obj= new Usercontroller();
	$email=$_POST['email'];
	$file_name = $_FILES['img']['name']; 
	echo $file_name;
	$file_tmp =$_FILES['img']['tmp_name'];
	$file_name1=$obj->uploadImage($file_name);
	if(!isset($error))
	{
		// if($file_name !="")
		// {
			$smtp=mysqli_query( $obj1->connect(),"SELECT img FROM users where email= '$email'");
			$row = mysqli_fetch_assoc($smtp);
			$deleteimage=$row['img'];
			$deleteUrl=trim($deleteimage);
			echo $deleteUrl;
			// unlink("C:/xampp/htdocs/meet/frontend/image/".$deleteUrl);
			move_uploaded_file($file_tmp,"../image/".$new_image_name);
			echo $new_image_name;
			$data=$_POST;
			$addr=$_POST['addr'];
			$obj->update($data,$new_image_name,$obj1);
		// }
	}
	
}

?>