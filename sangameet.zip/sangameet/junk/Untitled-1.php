<div id="carouselExampleCaptions" class="carousel slide">
		
		<?php
			$i = 0;
		  	foreach ($sliders as $slider){
				$filename= $slider['img'];
		?>
	  <div class="carousel-indicators">
		<?php 
			if($i==0)
			{
		?>
				<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="<?php  echo $i ;?>" class="<?php echo 'active';?>" aria-current="true" aria-label="true"></button>
		<?php
			} else {
		?>
				<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="<?php echo  $i ;?>" aria-label="true" aria-current="true"></button>	
		<?php
			}
		?>
		<!-- <button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="1" aria-label="Slide 2"></button>
		<button type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide-to="2" aria-label="Slide 3"></button> -->
	  </div>
	  <div class="carousel-inner">

				<div class="carousel-item <?php if($i == 0){echo 'active';} ?>">
				<img class="sliderimg " src="image/<?php  echo $filename ?>" class="d-block w-100" >
				<div class="carousel-caption d-none d-md-block">
					<h5><?php echo $slider['title'] ?></h5>
					<p><?php echo $slider['description']?></p>
				</div>
				</div>
		<?php
			$i++;
		  }
		
		?>
	  </div>
	  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="prev">
		<span class="carousel-control-prev-icon" aria-hidden="true"></span>
		<span class="visually-hidden">Previous</span>
	  </button>
	  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleCaptions" data-bs-slide="next">
		<span class="carousel-control-next-icon" aria-hidden="true"></span>
		<span class="visually-hidden">Next</span>
	  </button>
	</div class="mb-5">