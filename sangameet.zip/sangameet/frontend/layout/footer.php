
<section>
    <footer>
        <div class="row">
            <div class="col">
                <img src="logo/sanga1.png" class="logo">
                <p>SangaMeet is an online service to help you meet real new friends, from your neighborhood or from around the world.</p>
            </div>

            <div class="col">
                <h3>Office</h3>
                <p>ITPL Road<p>
                <p>Whitefield,Banglore</p>   
            </div>

            <div class="col">
                <h3>Quick Links</h3>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="services.php">Services</a></li>
                    <li><a href="about.php">About Us</a></li>
                    <li><a href="registration.php">SignUP</a></li>
                    <li><a href="login.php">Login</a></li> 
                </ul>
            </div> 

            <div class="col">
                <h3>Newsletter</h3>
                <form>
                    <input type="email" placeholder="Enter your Email id ">
                </form>
            </div>
        </div>
    </footer>  
</section>
    