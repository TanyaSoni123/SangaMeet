<div class="header">
	<nav>
		<a href="index.php"><img src="logo/sanga1.png"></a>
		<!--<a ><img src="./../img/sanga1.png"></a>-->
		<?php if(isset($_SESSION['name']))
			{
		?>
			<div class='nav-name'>
                Hi, <?php echo $_SESSION['name'] ?> 
            </div>
		<?php }	?>
			<div class="nav-links">
				<ul>
					<li><a href="index.php">HOME</a></li>
					<li><a href="about.php">ABOUT</a></li>
					<!-- <li><a href="services.php">SERVICES</a></li> -->
		<?php
            //Check if user is loging or not
            if (!isset($_SESSION["id"])) {
        ?>
					
					<li><a  href="registration.php">SIGNUP</a></li>
					<li><a href="login.php">LOGIN</a></li>
		<?php
        } else {
        ?>
					<li><a href="profile.php">PROFILE</a></li>
					<li><a href="city.php">MEMBERS</a></li>
					<li><a href="includes/logout.php">LOGOUT</a></li>
				</ul>
			</div>
		<?php
            }
        ?>
	</nav>
</div>

	 

