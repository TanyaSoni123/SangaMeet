<?php
   include "includes/headlinks.php";
?>


<body>   
<?php
 session_start();
 include "layout/header.php";
 ?>
<?php
 include("controller/Usercontroller.php");
  if(isset($_SESSION['id'])){
  $users_id=$_SESSION['id'];
  $obj=new Usercontroller();
 $city = $obj->getCity($users_id);
 $results=$obj->cityMembers($users_id,$city);
  }
?> 
<div class="container">
   <div class="title">
        <h1 style="color:black!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;">Members belongs to your city</h1>
    </div>
    <div class="card">
       <div class="card-body">
<table class="table">
	<thead>
      <tr>
        <th>Profile</th>
        <th>Name</th>
        <th>Email</th>
        <th>Instagram</th>
        <th>Twitter</th>
        <th>Facebook</th>
        <th>Message</th>
        <th>Report</th>
     </tr>
	</thead> 
  <tbody>
  <?php
    if($results){
      foreach($results as $row){
  ?>
    <tr>
      <td><img  style="height:100px;" class="profile" src="image/<?php echo $row['img'] ;?>"></td>
      <td><?php echo $row['userName'];?></td>
      <td><?php echo $row['email'];?></td>
      <td><?php echo $row['instagram']; ?></td>
      <td><?php echo $row['twitter'];?></td>
      <td><?php echo $row['facebook'];?></td>
     <td><a href="rty">  <i class='fas fa-paper-plane me-2'></i></a></td>
     <td><a  class="report" href="report.php?reportid=<?php echo $row['memberid'];?>" ><i class="fas fa-exclamation-circle">Report</a></i>
     <!-- memberid=<?php echo $row['memberid'];?> -->

</td>
    </tr>
  <?php 
      }
    }
  ?>
  </tbody>
</table>
</div>
</div>
</div>
<?php
include "layout/footer.php";
?>

<!-- <script>
  $(document).ready(function(){
    $('.report').on("click",function(event){
      // console.log("here");
        event.preventDefault();
      var email = $(this).attr('dataEmail');
      // console.log(email);

      $.ajax({
        method:"POST",
        url:"report.php",
        data: {email:email, },
        success:function(response){

           console.log(response);
           	// window.location.href ="report.php";
        }
      });



    });


  });
</script> -->
</body>
</html>