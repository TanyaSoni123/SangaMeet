
<?php
 include "layout/header.php";
 include "includes/headlinks.php";
 ?>
 <div class="banner-container">
    <h2 class="white pb-3">Services</h2>
</div>
 <?php
 include "layout/footer.php";
?>