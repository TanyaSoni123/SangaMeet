<nav class="navbar navbar-expand-lg inav-color">
  <div class="container-fluid">
    <a class="navbar-brand iheading">Admin Panel</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
  </div>
</nav>

 <!-- <div class="d-flex align-items-start sidebar">
    
    <div class="nav flex-column nav-pills me-3" id="v-pills-tab" role="tablist" aria-orientation="vertical">
        <button class="nav-link" id="v-pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#v-pills-disabled" type="button" role="tab" aria-controls="v-pills-disabled" aria-selected="false" disabled>Core</button>
    <button class="nav-link active" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">Home</button>
    <button class="nav-link" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">Profile</button>
    <button class="nav-link" id="v-pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#v-pills-disabled" type="button" role="tab" aria-controls="v-pills-disabled" aria-selected="false" disabled>Disabled</button>
    <button class="nav-link" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-messages" type="button" role="tab" aria-controls="v-pills-messages" aria-selected="false">Messages</button>
    <button class="nav-link" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-settings" type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false">Settings</button>
  </div>
  <div class="tab-content" id="v-pills-tabContent">
    <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab" tabindex="0"><h3>home</h3><p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis impedit ipsum eum. Alias enim nemo odit fuga repellendus expedita architecto qui perferendis nihil, eum repellat laudantium consequatur. Iste consequuntur velit fugiat omnis veritatis sed? Voluptate odio mollitia atque, aspernatur blanditiis sapiente dolorem asperiores deserunt possimus adipisci excepturi esse alias animi eum nisi voluptates est numquam. Dicta?</p></div>
    <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab" tabindex="0">...</div>
    <div class="tab-pane fade" id="v-pills-disabled" role="tabpanel" aria-labelledby="v-pills-disabled-tab" tabindex="0">...</div>
    <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab" tabindex="0">...</div>
    <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab" tabindex="0">...</div>
  </div>
</div> 
 vertical sidebar
<div class="row">
    <div class="col-md-2 ">
        <div class="sidebar">
            <ul class="nav flex-column ">
            <li class="nav-item">
                <a class="nav-link disabled" aria-disabled="true">Core</a>
            </li>
            <li class="nav-item">
                <a class="nav-link active" aria-current="page" href="#">Active</a>
            </li>
            <li class="nav-item">
                <a class="nav-link disabled" aria-disabled="true">Menu</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Link</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#">Link</a>
            </li>
            <li class="nav-item">
                <a class="nav-link disabled" aria-disabled="true">ADMIN-MEMBERS</a>
            </li>
            </ul>
        </div>
    </div>
</div>-->

<aside style="float:left;" id="vertical-menu">
    <div class="sidebar" id="side_nav">
        <ul class="list-unstyled">
           
            <hr class="h-color ">
            <li class="dashboard_link active_link here"><a href="#" class="text-decoration-none px-3 py-3 d-block">Dashboard</a></li>
            <hr class="h-color mx-2">
            <li class="u_link"><a href="includes/.php" class="text-decoration-none px-3 py-3 d-block"><i class="fas fa-list"></i>Projects</a></li>
            <li class=""><a href="#" class="text-decoration-none px-3 py-3  justify-content-between"><span><i class="fas fa-envelope"></i>Message</span>d-block d-flex
            <span class="rounded-pill text-dark py-0 px-2 ">02</span></a></li>
            <li clas=""><a href="#" class="text-decoration-none d-block px-3 py-3"><i class="fas fa-users"></i>Users</a></li>
            <li clas=""><a href="#" class="text-decoration-none d-block px-3 py-3 ">Dashboard</a></li>
        </ul>
        <hr class="h-color mx-2">
        <ul class="list-unstyled">
            <li clas=""><a href="#" class="text-decoration-none d-block px-3 py-3">Dashboard</a></li>
            <li clas=""><a href="#" class="text-decoration-none d-block px-3 py-3">Dashboard</a></li>
        </ul>
        <div class="content"> 
            
        </div>
    </div>
</aside>
<div id="content" style="margin-left:240px;">
    <div class="inside-page" style="padding:20px">
              <div class="page_title_top" style="margin-bottom: 1.5rem!important;">
                <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;"> Dashboard</h1>
              </div>

              <!-- cards -->
              <div class="row">
                <div class="col-sm-6 col-lg-3">
                  <div class="panel panel-green ">
                    <div class="panel-heading">
                          <div class="row">
                            <div class="col-sm-3">
                              <i class="fa fa-users fa-4x"></i>
                            </div>
                            <div class="col-sm-9 text-right">
                              <div class="huge"><span>5</span></div>
                              <div>Total Clients</div>
                            </div>
                          </div>
                    </div>
                    <a href="clients.php">
                          <div class="panel-footer">
                            <span class="pull-left">View Details</span>
                            <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                            <div class="clearfix"></div>
                          </div>
                    </a>
                  </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-sm-3">
                                    <i class="fas fa-utensils fa-4x"></i>
                                </div>
                                <div class="col-sm-9 text-right">
                                    <div class="huge"><span>16</span></div>
                                    <div>Total Menus</div>
                                </div>
                            </div>
                        </div>
                        <a href="menus.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class=" col-sm-6 col-lg-3">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-sm-3">
                                    <i class="far fa-calendar-alt fa-4x"></i>
                                </div>
                                <div class="col-sm-9 text-right">
                                    <div class="huge"><span>32</span></div>
                                    <div>Total Appointments</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class=" col-sm-6 col-lg-3">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-sm-3">
                                    <i class="fas fa-pizza-slice fa-4x"></i>
                                </div>
                                <div class="col-sm-9 text-right">
                                    <div class="huge"><span>3</span></div>
                                    <div>Total Orders</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
              </div>
            














          </div>

</div> 

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script>
     var vertical_menu = document.getElementById("vertical-menu");
    var current = vertical_menu.getElementsByClassName("active_link");

                if(current.length > 0)
                {
                    current[0].classList.remove("active_link");   
                }
                
                    
                vertical_menu.getElementsByClassName('u_link')[0].className += " active_link";
    // $(".sidebar ul li").on('click' ,function(){ 
    //      $(".sidebar ul li.active").removeClass('active');
    //      $(this).addClass('active');
    // })  
</script>

  





