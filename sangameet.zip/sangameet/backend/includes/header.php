<header  class="headerMenu d-flex">
    <div class="nav-header">
        <a class="navbar-brand iheading" href="../frontend/index.php">
           <img src="../frontend/logo/sanga1.png" style="height:35px;"> Admin Panel
        </a> 
    </div> 
        <div class="dropdown">
                <button class="btn btn-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown" aria-expanded="false">
                    Lock & Key
                </button>
                <ul class="dropdown-menu">
                    <li><a class="dropdown-item" href="#">Edit Profile</a></li>
                    <li><a class="dropdown-item" href="#">Website Setting</a></li>
                    <li><a class="dropdown-item" href="#">Logout</a></li>
                </ul>
        </div>
       
</header>
<aside class="sidebar1">

    <div class="sidebar">
        <ul class="list-unstyled">

    <!-- <li ><a href="/meet/backend/usersprofile.php">user</a></li>
    <li><a href="/meet/backend/dashboard.php">dashboard</a></li>
    <li ><a href="/kognitos_01/wp-content/themes/New%20folder/services.php">Services</a></li>
  
/meet/backend/citydetails.php
/meet/backend/requests.php
/meet/backend/groups.php
/meet/backend/sliders.php
/meet/backend/notifications.php
/meet/backend/notifications.php -->
          <div>
               <button class="nav-link style1 " id="v-pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#v-pills-disabled" type="button" role="tab" aria-controls="v-pills-disabled" aria-selected="false"  disabled>MAIN</button> 
            </div>
            <hr class="h-color mb-1">
            <li class="  px-3 py-3  style"><a href="dashboard.php" >
                  <i class="fas fa-tachometer-alt me-2"></i>Dashboard</a></li>
            <hr class="h-color mb-1">



            <div>
                <button class="nav-link style1 " id="v-pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#v-pills-disabled" type="button" role="tab" aria-controls="v-pills-disabled" aria-selected="false"  disabled>USERS</button>
            </div>
            <li class=" px-3 py-3 " ><a href="usersprofile.php" class="style">
               <i class="fa-regular fa-user me-2"></i> Users Profile</a></li>
            <li class="  px-3 py-3 " ><a href="citydetails.php" class="style">
                <i class="fas fa-city me-2"></i>City Details</a></li>
            <li class="  px-3 py-3 " ><a href="requests.php" class="style">
                <i class="fa-regular fa-envelope me-2"></i>Requests</a></li>
            <li class=" px-3 py-3 " ><a href="groups.php" class="style">
                 <i class="fas fa-users me-2"></i>Groups</a></li>
            <hr class="h-color mb-1">


            <div>
                <button class="nav-link style1 " id="v-pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#v-pills-disabled" type="button" role="tab" aria-controls="v-pills-disabled" aria-selected="false"  disabled>UPDATES</button>
            </div>
            <li class=" px-3 py-3 " ><a href="sliders.php"class="style">
                <i class="fa-solid fa-sliders me-2"></i>Sliders</a></li>
            <li class=" px-3 py-3" ><a href="notifications.php"class="style">
                <i class='fas fa-paper-plane me-2'></i>
                 Notifications</a></li>
            <li class=" px-3 py-3 " ><a href="settings.php"class="style">
               <i class="fa-solid fa-gear me-2"></i> Settings</a> </li> 
        </ul>
    </div>
</aside>





<!-- <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script>
   $(document).ready(function () {
  $(".sidebar ul").on('click', 'li', function () {
    $(".sidebar ul li.active").removeClass('active'); // Remove 'active' class from all li elements
    $(this).addClass('active'); // Add 'active' class to the clicked li element
  });
}); 
</script> -->