<!DOCTYPE html>
<html lang="en">
<head>
  <title>Project Title</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
  <script src="../css/bootstrap.min.js"></script>
  <link rel="stylesheet" href="../css/home.css">
      <link href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" rel="stylesheet" />
      <link rel="stylesheet" 
href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
</head>
<body>
<header  class="headerMenu">
    <div class="nav-header">
        <a class="navbar-brand iheading" href="">
                Admin Panel
        </a> 
    </div>
    <li class="main-li webpage-btn ">
      <a class="nav-item-button " href="../../frontend/" target="_blank">
        <i class="fas fa-binoculars"></i>
          <span>View website</span>
      </a>
    </li>      
</header>
<main>
<section>
  <div class="container-fluid">
    <div class="row">
      <div class="col-lg-2">
        <div class="side-bar">
          <div class="nav flex-column nav-pills h-100" id="v-pills-tab"      role="tablist" aria-orientation="vertical">
              <button class="nav-link style1 " id="v-pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#v-pills-disabled" type="button" role="tab" aria-controls="v-pills-disabled" aria-selected="false"  disabled>MAIN</button>
              <hr class="h-color mx-1">
              <button class="nav-link active style" id="v-pills-home-tab" data-bs-toggle="pill" data-bs-target="#v-pills-home" type="button" role="tab" aria-controls="v-pills-home" aria-selected="true">
                <i class="fas fa-tachometer-alt me-2"></i>Dashboard</button>
              <hr class="h-color mb-1">
              <button class="nav-link style1" id="v-pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#v-pills-disabled" type="button" role="tab" aria-controls="v-pills-disabled" aria-selected="false" disabled>USERS</button>
              <hr class="h-color mb-1">
              <button class="nav-link style" id="v-pills-profile-tab" data-bs-toggle="pill" data-bs-target="#v-pills-profile" type="button" role="tab" aria-controls="v-pills-profile" aria-selected="false">
              <i class="fa-regular fa-user me-2"></i> Users Profile</button>
              <button class="nav-link style" id="v-pills-messages-tab" data-bs-toggle="pill" data-bs-target="#v-pills-messages" type="button" role="tab" aria-controls="v-pills-messages" aria-selected="false">
                <i class="fas fa-city me-2"></i>City Details</button>
              <button class="nav-link style" id="v-pills-settings-tab" data-bs-toggle="pill" data-bs-target="#v-pills-settings" type="button" role="tab" aria-controls="v-pills-settings" aria-selected="false">
                <i class="fa-regular fa-envelope me-2"></i>Requests</button>
              <button class="nav-link style" id="v-pills-contact-tab" data-bs-toggle="pill" data-bs-target="#v-pills-contact" type="button" role="tab" aria-controls="v-pills-contact" aria-selected="false">
                <i class="fas fa-users me-2"></i>Groups</button>
              <hr class="h-color mb-1">
              <button class="nav-link style1 " id="v-pills-disabled-tab" data-bs-toggle="pill" data-bs-target="#v-pills-disabled" type="button" role="tab" aria-controls="v-pills-disabled" aria-selected="false"  disabled>UPDATES</button>
              <hr class="h-color mb-1">
              <button class="nav-link style" id="v-pills-slider-tab" data-bs-toggle="pill" data-bs-target="#v-pills-slider" type="button" role="tab" aria-controls="v-pills-slider" aria-selected="false">
                <i class="fa-solid fa-sliders me-2"></i>Slider</button>
              <button class="nav-link style" id="v-pills-notification-tab" data-bs-toggle="pill" data-bs-target="#v-pills-notification" type="button" role="tab" aria-controls="v-pills-notification" aria-selected="false">
              <i class='fas fa-paper-plane me-2'></i> Notifications</button>
              <button class="nav-link style" id="v-pills-setting-tab" data-bs-toggle="pill" data-bs-target="#v-pills-setting" type="button" role="tab" aria-controls="v-pills-setting" aria-selected="false">
                <i class="fa-solid fa-gear me-2"></i>Settings</button>
              
          </div>
        </div>
      </div>
      <div class="col-lg-10">
        <div class="tab-content" id="v-pills-tabContent">
          <div class="tab-pane fade show active" id="v-pills-home" role="tabpanel" aria-labelledby="v-pills-home-tab">
            <!-- Dashboard -->
            <div class="inside-page" style="padding:20px">
              <div class="page_title_top" style="margin-bottom: 1.5rem!important;">
                <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;"> Dashboard</h1>
              </div>
              <!-- cards -->
              <div class="row">
                <div class="col-sm-6 col-lg-3">
                    <div class="panel panel-green ">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-sm-3">
                                    <i class="fa fa-users fa-4x"></i>
                                </div>
                                <div class="col-sm-9 text-right">
                                    <div class="huge"><span></span></div>
                                    <div>Total Users</div>
                                </div>
                            </div>
                        </div>
                        <a href="clients.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-3">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-sm-3">
                                    <i class="fas fa-utensils fa-4x"></i>
                                </div>
                                <div class="col-sm-9 text-right">
                                    <div class="huge"><span></span></div>
                                    <div>Total Menus</div>
                                </div>
                            </div>
                        </div>
                        <a href="menus.php">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                
                <div class=" col-sm-6 col-lg-3">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-sm-3">
                                    <i class="far fa-calendar-alt fa-4x"></i>
                                </div>
                                <div class="col-sm-9 text-right">
                                    <div class="huge"><span>32</span></div>
                                    <div>Total Appointments</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
                <div class=" col-sm-6 col-lg-3">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-sm-3">
                                    <i class="fas fa-pizza-slice fa-4x"></i>
                                </div>
                                <div class="col-sm-9 text-right">
                                    <div class="huge"><span></span></div>
                                    <div>Total Orders</div>
                                </div>
                            </div>
                        </div>
                        <a href="#">
                            <div class="panel-footer">
                                <span class="pull-left">View Details</span>
                                <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                <div class="clearfix"></div>
                            </div>
                        </a>
                    </div>
                </div>
              </div>
              <!-- cards ends-->

              <!-- start nav -->
              <div></div> 

              <!-- end nav -->

            </div>
            <!-- dashboard ends -->
          </div>
          <div class="tab-pane fade" id="v-pills-profile" role="tabpanel" aria-labelledby="v-pills-profile-tab">
            <div class="inside-page" style="padding:20px">
            <div class="page_title_top" style="margin-bottom: 1.5rem!important;">
                <!-- users start -->
                <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;"> Users</h1>
            <div class="card">
              <div class="card-header">
                <div class="page_title_top" style="margin-bottom: 1.5rem!important;">
                <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;"> Users</h1>
              </div>
              </div>
              <div class="card-body">
                <table class="table table-bordered users-table">
                            <thead>
                                <tr>
                                    <th scope="col">Username</th>
                                    <th scope="col">E-mail</th>
                                    <th scope="col">Full Name</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>  
              </div>
            </div>
            </div>
            <!-- users End-->
            </div>
          </div>
          <div class="tab-pane fade" id="v-pills-messages" role="tabpanel" aria-labelledby="v-pills-messages-tab">
             <!-- cities start -->
            <div class="card">
              <div class="card-header">
                <div class="page_title_top" style="margin-bottom: 1.5rem!important;">
                <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;">Total Cities</h1>
              </div>
              </div>
              <div class="card-body">
                <table class="table table-bordered users-table">
                            <thead>
                                <tr>
                                    <th scope="col">City Name</th>
                                    <th scope="col">Total Users</th>
                                    <th scope="col">Users Details</th>
                                </tr>
                            </thead>
                            <tbody>
                            </tbody>
                        </table>  
              </div>
            </div>
             <!-- cities ends -->
          </div>
          <div class="tab-pane fade" id="v-pills-settings" role="tabpanel" aria-labelledby="v-pills-settings-tab">
             <!-- requests start -->
            <div class="card">
              <div class="card-header">
                <div class="page_title_top" style="margin-bottom: 1.5rem!important;">
                <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;">Requests</h1>
              </div>
              </div>
              <div class="card-body">
                <table class="table table-bordered users-table">
                            <thead>
                                <tr>
                                    <th scope="col">Username</th>
                                    <th scope="col">E-mail</th>
                                    <th scope="col">City</th>
                                    <th scope="col">Time</th>
                                    <th scope="col">Responded</th>
                                    <th scope="col">Rejected</th>
                                    <th scope="col">AddToGroup</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>  
              </div>
            </div>
             <!-- request ends-->
          </div>
          <div class="tab-pane fade" id="v-pills-contact" role="tabpanel" aria-labelledby="v-pills-contact-tab">
            <!-- groups start -->
            <div class="card">
              <div class="card-header">
                <div class="page_title_top" style="margin-bottom: 1.5rem!important;">
                <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;">Groups</h1>
              </div>
              </div>
              <div class="card-body">
                <table class="table table-bordered users-table">
                            <thead>
                                <tr>
                                    <th scope="col">Sr.no</th>
                                    <th scope="col">Groups</th>
                                    <th scope="col">City</th>
                                    <th scope="col">Created</th>
                                    <th scope="col">Total Members</th>
                                    <th scope="col">Admins</th>
                                    <th scope="col">Details</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>  
              </div>
            </div>
            <!-- groups ends -->
          </div>
          <div class="tab-pane fade" id="v-pills-slider" role="tabpanel" aria-labelledby="v-pills-slider-tab">
            <!-- slider start -->
            <div class="card">
              <div class="card-header">
                <div class="page_title_top" style="margin-bottom: 1.5rem!important;">
                <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;">Slider</h1>
              </div>
              </div>
              <div class="card-body">
                <table class="table table-bordered users-table">
                            <thead>
                                <tr>
                                    <th scope="col"></th>
                                    <th scope="col">Responded</th>
                                    <th scope="col">Rejected</th>
                                    <th scope="col"></th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>  
              </div>
            </div>
            <!-- slider end -->
          </div>
          <div class="tab-pane fade" id="v-pills-notification" role="tabpanel" aria-labelledby="v-pills-notification-tab">
             <!-- Notifications  start -->
            <div class="card">
              <div class="card-header">
                <div class="page_title_top" style="margin-bottom: 1.5rem!important;">
                <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;">Notifications</h1>
              </div>
              </div>
              <div class="card-body">
                <table class="table table-bordered users-table">
                            <thead>
                                <tr>
                                    <th scope="col">Sr.</th>
                                    <th scope="col">New user</th>
                                    <th scope="col">Rejected</th>
                                    <th scope="col">AddToGroup</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>  
              </div>
            </div>
             <!-- notification ends -->
          </div>
          <div class="tab-pane fade" id="v-pills-setting" role="tabpanel" aria-labelledby="v-pills-setting-tab">
             <!-- setting  start -->
            <div class="card">
              <div class="card-header">
                <div class="page_title_top" style="margin-bottom: 1.5rem!important;">
                <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;">Settings</h1>
              </div>
              </div>
              <div class="card-body">
                <table class="table table-bordered users-table">
                            <thead>
                                <tr>
                                    <th scope="col">Sr.</th>
                                    <th scope="col">New user</th>
                                    <th scope="col">Rejected</th>
                                    <th scope="col">AddToGroup</th>
                                </tr>
                            </thead>
                            <tbody>

                            </tbody>
                        </table>  
              </div>
            </div>
             <!-- setting ends -->
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
</main>
<footer></footer>
</body>
</html>
