
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>admin</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
	 <link href="https://use.fontawesome.com/releases/v5.11.2/css/all.css" rel="stylesheet" />
     	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>
        <style>
            .outer{
                  display: flex;
                justify-content: center;
            align-items: center;
            border: 1px solid #000;
             height: 100vh;
            }
            p{
                font-weight:lighter;
              font-family: 'Poppins', sans-serif;
              font-size:64px;
            }
            .inner{
                width:700px;
            }
        </style>
<body>
    <div class="outer">
       
        <div class="inner" >
             <p >Admin Panel</p>
            <form action="controller/Usercontroller.php" method="POST" >
                            <label class="form-label " >Name</label>
                            <input type="text" class="form-control" placeholder="username" name="username" >
                         
    
                         
                          <label for="exampleFormControlInput3" class="form-label ">Password</label>
                          <input type="password" class="form-control mb-3" id="exampleFormControlInput3" placeholder="name@example.com"   name="password" >
                <input type="submit"class="btn btn-primary" name="adminlogin">
            </form>
        </div>
    </div>
    
</body>
</html>