<?php 
    include 'includes/headlink.php';
    include 'includes/header.php';
?>
<?php
 include 'controller/Usercontroller.php';
 $obj=new Usercontroller();
  $rows=$obj->getCityDetails();
//   print_r($rows);
 ?>
<div class="topdivmargin">
<div  class="padding">
    <div class="title">
        <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;">City Details</h1>
    </div>
    <div class="card">
        <div class="p-3 cardtitle">City Details</div>
        <div class="card-body p-2">
            <table class="table table-bordered users-table">
                <thead>
                    <tr>
                        <th scope="col">City Name</th>
                        <th scope="col">Total Users</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        foreach($rows as $row){
                            echo'<tr>';
                        echo'<td>'.$row['city'].'</td>';
                        echo'<td>'.$row['total_users'].'</td>';
                         echo'</tr>';
                            
                        }
                    ?>

                </tbody>
            </table>  
     
        </div>
    </div>
</div>

</div>