<?php
include "C:/xampp/htdocs/meet/connection.php";
 class Usercontroller
 {
	use Connection;
    public $dbObj;
	 public function  __construct()
	 {
	 	//$this->dbObj = new Connection();
	 }
	// when admin login
	public function adminLogin($username,$requestPassword)
	{
			
		$sql="SELECT password FROM users WHERE is_admin=1";
		$result=$this->connect()->query($sql);
		$num=mysqli_num_rows($result);
		//print_r($num); die;
		if($num==1)
		{   
			$row=mysqli_fetch_assoc($result);
			$hashedpassword=$row['password'];
			// echo $hashedpassword;	
			if(password_verify($requestPassword,$hashedpassword))
			{
				
				// echo "yes";
				if(isset($_SESSION['error']) && !isset($_SESSION['id'])){
					unset($_SESSION['error']); 
				}
				$_SESSION['adminid']=$row['id'];
				$_SESSION['adminname'] = $row['name'];
				$_SESSION['adminemail'] = $row['email'];
				// echo "<pre>";print_r($_SESSION); die;
				header("Location:../dashboard.php");
			}else{
				$_SESSION['error'] = "Password does not match!"; 
				header("Location:../index.php");
			}					
		}
	}
	// add to slider
	public function uploadImage($file_name)
	{
		$file_name_array =explode(".", $file_name);
		$extention = end($file_name_array);
		//here to store a new name for a file 
		$new_image_name = 'user_'.time().'.'.$extention;
		//echo $new_image_name; 
		
		if($_FILES['img']['size'] >1000000){
			$error[]="Sorry, your image is tooo large.Upload less than 1Mb in size";

		}
		
		// if($file_name != "")
		// {
		// 	if($extention!="jpg" &&  $extention!="png"  && $extention!="jpeg" && $extention!="gif" &&$extention!="PNG" && $extention!="JPG" &&$extention!="GIF" && $extention!="JPEG" ){
		// 	$error[]="Sorry ,only JPG,JPEG,PNG & GIF files are allowed";
		// 	}
		// }
		return($new_image_name);
	}
	
	public function insertSliderTable($url,$description,$img,$title)
	{
		$sql="INSERT INTO sliders (url, description, img, title) VALUES('$url','$description','$img','$title')";
		$result = $this->connect()->query($sql);
		if($result){
			echo "updated";
				header("Location:../sliders.php");
		}else{
			echo "error";
		}
	}
	public function selectSlider()
	{
		$sql="SELECT * FROM sliders";
		$result= $this->connect()->query($sql);
		if($result->num_rows > 0)
		{ 
			$num_rows=$result->num_rows;
			while($row = $result->fetch_assoc())
			{
				$data[]=$row;
			} 
		}
		return $data;		
		 
	}
	// dynamic slider to display at homepage
	public function selectSliderStatus()
	{
		$sql="SELECT * FROM sliders where status = 1";
		$result= $this->connect()->query($sql);
		if($result->num_rows > 0)
		{ 
			$num_rows=$result->num_rows;
			while($row = $result->fetch_assoc())
			{
				$data[]=$row;
			} 
		}
		return $data;		 
	}
	// public function getId($id)
	// {
	// 	$sql = "SELECT * FROM sliders WHERE id='$id'";
	// 	$results =$this->connect()->query($sql);
	// 	// print_r($results);
	// 	if($results->num_rows > 0)
	// 	{
	// 		$row=$results->fetch_assoc();
	// 		return $row;		
	// 	}
	// }
	public function displaySliderUpdate($id)
	{
		$sql="SELECT * FROM sliders Where id='$id'";
		$result = $this->connect()->query($sql);
		$row=$result->num_rows;
		if($row==1)
		{
			$data = $result->fetch_assoc();
			return $data;
		}
	}
	public function updateSlider($title,$url,$description,$filename1,$id)
	{
		$sql ="UPDATE sliders SET title = '$title', url ='$url' , description  ='$description', img ='$filename1' WHERE id =$id";
		$result = $this->connect()->query($sql);
		if($result)
		{
			echo "updated";
			header("location:../sliders.php");

		}

	}
	public function checkFile($title,$url,$description,$filename,$id,$filetmp)
	{
		if($filename !="")
		{
			$filename1=$this->uploadImage($filename);
			$sql="SELECT img FROM sliders where id = '$id'";
			$result = $this->connect()->query($sql);
			$row = mysqli_fetch_assoc($result);
			$deleteimage= $row['img'];
			$deleteUrl=trim($deleteimage);
			//echo $deleteUrl;
			 unlink("../../frontend/image/".$deleteUrl);
			 move_uploaded_file($filetmp,'../../frontend/image/'.$filename1);
			$this->updateSlider($title,$url,$description,$filename1,$id);

		}
		else{
			echo "here";
		$this->Updatesliderwithoutfile($title,$url,$description,$id);
		}

	}
	public function Updatesliderwithoutfile($title,$url,$description,$id)
	 {
		$sql ="UPDATE sliders SET title= '$title', url ='$url' ,description =' $description' WHERE id='$id'";
		$result = $this->connect()->query($sql);
		if($result)
		{
			echo "updated";
			header("location:../sliders.php");

		}
	 }
	 //update the status of slider 
	public function updateStatus($statusID,$status)
	{
		$sql = "UPDATE sliders SET status = $status where id = '$statusID'";
		$result=$this->connect()->query($sql);
		if($result){
			echo "updated";
		}
	}
	public function approved($id,$status)
	{
		$sql1=" UPDATE users SET status = '$status' where id='$id' ";
		$result1=$this->connect()->query($sql1);
		if($result1)
		{
			// header("Location:../usersprofile.php");
		}
	}
	public function displayUserData()
	{
		$sql_1 = "SELECT *
		FROM users";
 		$result_1 = $this->connect()->query($sql_1);
		if($result_1->num_rows > 0)
		{ 
			
			
			while($row = $result_1->fetch_assoc())
			{
				
				$data[]=$row;
			} 
		}
		return $data;
	}
	// citydetails
	public function getCityDetails()
	{
		$sql="SELECT DISTINCT city, COUNT( distinct users_id) as total_users FROM addresses LEFT JOIN users ON addresses.users_id = users.id GROUP BY addresses.city;";
		$result = $this->connect()->query($sql);
		if($result->num_rows > 0)
		{ 
			while($row = $result->fetch_assoc())
			{
				$data[]=$row;
			} 
		}
		return $data;
	}
	// insert report data 
	public function insertIntoReport($reportid,$description,$image_path)
	{
		$sql="INSERT INTO report (id,description,image_path) VALUES ";


	}
 }
// when admin login
 if(isset($_POST["adminlogin"]))
 {
	// echo "here";
	$obj=new Usercontroller();
	$obj->adminLogin($_POST['username'],$_POST['password']);
 }
// add to slider
 if(isset($_POST["add"]))
 {
	$url=$_POST["url"];
	$title=$_POST["title"];
	$description = $_POST["description"];
	$filename=$_FILES['img']['name'];
	$filetmp=$_FILES['img']['tmp_name'];
	$obj=new Usercontroller();
	$img=$obj->uploadImage($filename);
	move_uploaded_file($filetmp,"../../frontend/image/".$img);
	$obj->insertSliderTable($url,$description,$img,$title);
 }
// update sliders rows
 if(isset($_POST["update"]))
 {
	$id=$_POST['id'];
	$obj= new Usercontroller();
	$title= $_POST['title'];
	$url=$_POST['url'];
	$description = $_POST['description'];
	$filename = $_FILES['img']['name'];
	$filetmp = $_FILES['img']['tmp_name'];
	$data=$_POST;
	$obj->checkFile($title,$url,$description,$filename,$id,$filetmp);

 }
// when slider will give status
 if(isset($_POST["dataId"]))
 {
	$statusID = $_POST["dataId"];
	$status= $_POST["status"];
	$obj = new Usercontroller();
	$obj->updateStatus($statusID,$status);
 }
 //when admin willl approve
if (isset($_POST['choose']))
{
		echo "here";
		$id = $_POST['choose'];
		echo $id;
		$status =$_POST['status'];
		echo $status;
	
		$obj= new Usercontroller();
        $obj->approved($id,$status);
}
//when user made a report
if(isset($_POST["report"]))
{
	$description = $_POST["description"];
	$reportid = $_POST["reportid"];

   	// echo"<pre>"; print_r($_FILES['files']); 

	foreach( $_FILES['files']['tmp_name'] as $key => $tmp_name )
	{
        $file_name = $_FILES['files']['name'][$key];
        $file_size = $_FILES['files']['size'][$key];
        $file_tmp = $_FILES['files']['tmp_name'][$key];
        $file_type = $_FILES['files']['type'][$key];
	
		$upload = '../report_images/';
		$new_file_name = $upload.$file_name;

	if(move_uploaded_file($file_tmp,$new_file_name))
	{
        //  echo "here";
		$image_path[] = $new_file_name;


    } else {
        echo "there";
    } 
	}
	print_r($image_path);
	$obj = new Usercontroller();
	$obj->insertIntoReport($reportid,$description,$image_path);
}



?>