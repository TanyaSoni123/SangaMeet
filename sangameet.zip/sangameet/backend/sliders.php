<?php 
    include 'includes/headlink.php';
    include 'includes/header.php';
    include 'controller/Usercontroller.php';
$obj = new Usercontroller();
 $rows=$obj->selectSlider();
?>
<head>
    <style>
        .upload{
            margin:auto;
        }
        .picture{
            margin:auto;
         width: 192px;
        height: 192px;
        position: relative;
        border-radius: 100%;
        border: 6px solid cyan;
        box-shadow: 0px 2px 4px 0px rgba(0, 0, 0, 0.1);
        }
        .file{
            width:13px;
        }
    </style>
</head>
<div class="topdivmargin">
<div  class="padding">
    <div class="title ">
        <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;">Sliders</h1>
        
    </div>
    <div class="card">
        <div class="p-3 cardtitle">Sliders
            
            <!-- Button trigger modal -->
            <button class="btn btn-info" style="color:white ; float:right;" data-bs-toggle="modal" data-bs-target="#exampleModal"><i class="fa fa-plus me-2" ></i>ADD</button>
            


            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5 justify-content-center" id="exampleModalLabel">Add</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form action="controller/Usercontroller.php"  method="POST" enctype="multipart/form-data">
                       
                        <div class="mb-3">
                           <input type='file' name="img" id="img" accept=".png, .jpg, .jpeg" />
                        </div>
                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" id="url" placeholder="TITLE" name="title">
                        </div>
                        <div class="mb-3">
                            <label for="url" class="form-label">Url</label>
                            <input type="text" class="form-control" id="url" placeholder="URL" name="url" >
                        </div>
                        <div class="mb-3">
                            <label for="imgdescription" class="form-label">Description</label>
                            <textarea class="form-control" id="imgdescription" rows="3" name="description"></textarea>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
                            <button type="submit" name="add" class="btn btn-info text-white">Add</button>
                        </div>
                    </form>
                </div>
                </div>
            </div>
            </div>
        </div>
        <div class="card-body p-2">
            <table class="table table-bordered users-table">
                <thead>
                    <tr>
                        <th scope="col">Sr.no</th>
                        <th scope="col">TITLE</th>
                        <th scope="col">Url</th>
                        <th scope="col">description</th>
                        <th scope="col">Image</th>
                        <th scope="col">Status</th>
                        <th scope="col">Add</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                     $i=1; 
                    foreach($rows as $row){
                        echo '<tr>';
                        echo '<td>' . $i. '</td>';
                        echo '<td>'.$row['title'].'</td>';
                        echo '<td><a href="'.$row['url'].'" target="_blank">'.$row['url'].'</a></td>';
                        $filename = $row['img'];
                    ?>
                    <td><?php echo $row['description']?></td>
                    <td><img  style="height:100px;" src="../frontend/image/<?php echo $filename; ?>" alt="<?php echo $filename;?>"></td>
                    <td><div class="form-check form-switch">
                        <?php   
                        $statuses = $row['status'];      
                        ?>
                     
                        <input class="form-check-input changeStatus" type="checkbox" role="switch" id="flexSwitchCheckChecked_<?php echo $row['id']; ?>" name = "active" data-id ="<?php echo $row['id']; ?>" <?php if(isset($row['status'])){ if($statuses == 1 ) {echo "checked";}} ?> > 
                        <label class="form-check-label" for="flexSwitchCheckChecked_<?php echo $row['id']; ?>">Active</label>
                        </div>
                    </td>
                    <td style="text-align:center;"><a style="color:white;" class="btn  btn-info " href="sliderupdate.php?update=update&id=<?php echo $row['id'];?>">Update</a>
                     </td>
                    <?php    
                        echo '</tr>';
                        $i++;
                    }
                    ?>
                   
                </tbody>
            </table>  
        </div>
    </div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
    $(document).ready(function () {
        $(".changeStatus").on("change", function () {
            var dataId = $(this).attr('data-id');
            var changeStatus= $(this).is(":checked")?1:0;
            // console.log(dataId);
            // console.log(changeStatus);
            // Send an AJAX request to update the value in PHP
            $.ajax({
                type: "POST",
                url: "controller/Usercontroller.php",
                data: { dataId: dataId,
                status:changeStatus },
                success: function (response) {
                    console.log('response' + response)
                }
            });
        });
    });
</script>




