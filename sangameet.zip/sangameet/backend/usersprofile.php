
<?php 
    include 'includes/headlink.php';
    include 'includes/header.php';
    include 'controller/Usercontroller.php';
    $obj= new Usercontroller();
    $rows=$obj->displayUserData();
?>

<div class="topdivmargin">
<div  class="padding">
    <div class="title">
        <h1 style="color: #5a5c69!important;font-size: 1.75rem;font-weight: 400;line-height: 1.2;">Users Profile</h1>
    </div>

    <div class="card">
        <div class="p-3 cardtitle">Users Details</div>
        <div class="card-body p-2">
            <table  id = "tablename" >
                <thead> 
                    <tr>
                        <th scope="col">Username</th>
                        <th scope="col">E-mail</th>
                        <th scope="col">Status</th>
                        <th scope="col">Option</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    foreach($rows as $row)
                    {
                       
                        echo'<tr>';
                        echo'<td>'.$row['name'].'</td>';
                        echo'<td>'.$row['email'].'</td>';
                        echo'<td>'.$row['status'].'</td>';
                        // echo'<td>'.$row['users_id'].'</td>';
                        echo'<td>'
                    ?>
                        <select name="choose" class="choose">

                            <option value="<?php echo $row['id'];?>">PENDING</option>
                            <option value="<?php echo $row['id'];?>" class="approved" >APPROVED</option>
                            <option value="<?php echo $row['id'];?>">REJECTED</option>
                        </select>
                        <!-- </div> -->
                    <?php
                        '</td>';
                        echo'</tr>';
                    }
                    ?>

                </tbody>
            </table>  
        </div>
    </div>
</div>
</div>
<script>
    $(document).ready(function(){
        //alert("hwwww");
        $('#tablename').DataTable();
        $(document).on('click','.choose',function() {
            //$('.choose').click(function () {
            // console.log("here");
            var $this = this;
            var approved = $($this).val();
            var status = $($this).find(':selected').text();
            // alert(status);
            // var approved = $('.approved').val();
            $.ajax({
                type: "POST",
                url: "controller/Usercontroller.php",
                data: { choose: approved,
                status:status, },
                success: function (response) {
                    console.log(response);
                    console.log(status);
                    $($this).parent().prev().text(status);
                }
            });
        });
    })
</script>
